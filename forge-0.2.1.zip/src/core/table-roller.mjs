/* FORGE Table Roller — resolves and rolls the generation RollTables shipped in the
 * `forge.generators` compendium (transcribed from the FORGE Anniversary Edition
 * v1.1.2 rulebook, CC BY 4.0). Every table document's `_id` equals its stable id,
 * so callers just pass that id (e.g. "generator-dungeon-theme-0001").
 * Results may carry `flags.forge.subTableId` to point at a nested table (the book's
 * own d6-within-d6 subtables); pass `{ chain: true }` to follow that automatically.
 */

const PACK_ID = "forge.generators";

let cachedPack = null;
function pack() {
  if (cachedPack) return cachedPack;
  cachedPack = game.packs.get(PACK_ID) ?? null;
  if (!cachedPack) console.warn(`forge | Compendium pack ${PACK_ID} is unavailable.`);
  return cachedPack;
}

export class ForgeTableRoller {
  static async getTable(tableId) {
    const compendium = pack();
    if (!compendium) return null;
    const table = await compendium.getDocument(tableId);
    if (!table) console.warn(`forge | Generator table not found: ${tableId}`);
    return table;
  }

  /**
   * Rolls a single table by stable id and returns a plain result summary.
   * Does not create a chat message or mutate the table's `drawn` state, so it is
   * safe to call repeatedly during generation.
   */
  static async roll(tableId, { chain = false, trail = [] } = {}) {
    const table = await this.getTable(tableId);
    if (!table) return { tableId, text: null, results: [], trail };
    const roll = await table.roll();
    const drawn = roll.results?.[0] ?? null;
    const entry = {
      tableId,
      tableName: table.name,
      text: drawn?.description ?? drawn?.name ?? null,
      range: drawn?.range ?? null,
      flags: drawn?.flags?.forge ?? {}
    };
    const nextTrail = [...trail, entry];
    const subTableId = entry.flags.subTableId;
    if (chain && subTableId) return this.roll(subTableId, { chain, trail: nextTrail });
    return { tableId, text: entry.text, results: nextTrail, trail: nextTrail };
  }

  /** Rolls several tables independently (e.g. Delve Deeper's "Where" + "What" axes). */
  static async rollMany(tableIds, options = {}) {
    const draws = await Promise.all(tableIds.map((id) => this.roll(id, options)));
    return draws;
  }
}

export function registerForgeTableRoller() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.TableRoller = ForgeTableRoller;
}
