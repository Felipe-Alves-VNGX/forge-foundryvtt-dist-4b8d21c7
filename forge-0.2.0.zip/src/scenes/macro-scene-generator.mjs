/* FORGE Macro Scene Generator — abstract, interactive, non-tactical maps.
 * Dungeon and Wilderness content is rolled from the `forge.generators` compendium
 * (RollTables transcribed from the FORGE Anniversary Edition v1.1.2 rulebook,
 * CC BY 4.0) via ForgeTableRoller, plus the 2D wilderness terrain tables in
 * wilderness-tables.mjs. See docs/specs/FORGE-Scene-Generation-SPEC.md §9.
 */

import { ForgeTableRoller } from "../core/table-roller.mjs";
import { WILDERNESS_TERRAINS, nextTerrain, terrainFeature } from "./wilderness-tables.mjs";

const forgeFlag = (kind, generatorId, extra = {}) => ({
  schemaVersion: 3,
  sceneKind: kind,
  sceneMode: "draft",
  distanceMode: "bands",
  visibilityPolicy: "public-with-gm-private-notes",
  generatorId,
  seed: foundry.utils.randomID(),
  areas: [],
  hexes: [],
  connections: [],
  notes: [],
  wallRefs: [],
  doorRefs: [],
  discovery: {},
  lastAreaId: null,
  lastHexId: null,
  publicSceneUuid: null,
  gmSceneUuid: null,
  reconcile: { status: "clean", lastRun: null, conflicts: [] },
  ...extra
});

const gridType = (kind) => {
  if (kind === "wilderness") return CONST.GRID_TYPES.HEXODDR ?? CONST.GRID_TYPES.HEXODDQ ?? 2;
  return CONST.GRID_TYPES.GRIDLESS ?? 0;
};

// Foundry v13 requires embedded document `_id`s to be 16-character alphanumeric
// (the foundry.utils.randomID() format). The human-readable identifiers used to
// keep generator output legible are preserved as flags.forge.stableId instead.
const wallSenseNormal = () => CONST.WALL_SENSE_TYPES?.NORMAL ?? 20;
const wallMovementNormal = () => CONST.WALL_MOVEMENT_TYPES?.NORMAL ?? 20;
const doorType = () => CONST.WALL_DOOR_TYPES?.DOOR ?? 1;
const doorClosed = () => CONST.WALL_DOOR_STATES?.CLOSED ?? 0;

function rectangleDrawing(id, x, y, width, height, label = "") {
  return {
    _id: foundry.utils.randomID(),
    x,
    y,
    shape: { type: CONST.DRAWING_TYPES?.RECTANGLE ?? "r", width, height },
    fillType: 1,
    fillColor: "#637D4F",
    fillAlpha: 0.16,
    strokeWidth: 2,
    strokeColor: "#A85C32",
    text: label,
    fontSize: 18,
    flags: { forge: { generated: true, stableId: id } }
  };
}

function wall(id, x1, y1, x2, y2, { door = 0, secret = false, areaId = null, hexId = null } = {}) {
  return {
    _id: foundry.utils.randomID(),
    c: [x1, y1, x2, y2],
    move: wallMovementNormal(),
    sight: wallSenseNormal(),
    light: wallSenseNormal(),
    sound: wallSenseNormal(),
    door,
    ds: door ? doorClosed() : 0,
    flags: { forge: { generated: true, stableId: id, secret, areaId, hexId } }
  };
}

async function createJournal(name, pages, { gmOnly = true } = {}) {
  const ownership = gmOnly ? CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE : CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER;
  return foundry.documents.JournalEntry.implementation.create({
    name,
    ownership: { default: ownership },
    pages: pages.map((page, index) => ({
      _id: page.id ?? undefined,
      name: page.name ?? `Page ${index + 1}`,
      type: "text",
      text: { format: 1, content: page.content ?? "" },
      ownership: { default: ownership }
    })),
    flags: { forge: { generated: true, gmOnly } }
  });
}

async function rollText(tableId, fallback = "") {
  const result = await ForgeTableRoller.roll(tableId);
  return result.text ?? fallback;
}

export class ForgeMacroSceneGenerator {
  /** Rolls the FORGE Dungeon generation table chain and returns a scene preview. */
  static async dungeonPreview({ name = "[DUNGEON] FORGE Dungeon", areaCount = null, theme = null, seed = null } = {}) {
    const sizeText = await rollText("generator-dungeon-size-0001", "Medium — 2 themes, 10 total areas");
    const sizeMatch = /(\d+)\s+total areas/i.exec(sizeText);
    const themeCountMatch = /(\d+)\s+themes?/i.exec(sizeText);
    const rolledTotal = sizeMatch ? Number(sizeMatch[1]) : 10;
    const themeCount = Math.max(1, Number(themeCountMatch?.[1]) || 1);
    const count = Math.max(2, Math.min(36, Number(areaCount) || rolledTotal));

    const themes = theme ? [theme] : [];
    while (themes.length < themeCount) themes.push(await rollText("generator-dungeon-theme-0001", "Unthemed"));

    const builder = await rollText("generator-dungeon-foundation-builder-0001", "Natural formation");
    const functionText = await rollText("generator-dungeon-foundation-function-0001", "Unknown — play and see");
    const functionKey = functionText.split(/[—-]/)[0].trim().toLowerCase().replace(/[^a-z]+/g, "-").replace(/(^-|-$)/g, "");
    const uniqueTableId = `generator-dungeon-unique-${functionKey}-0001`;

    const uniqueCount = Math.min(themeCount, count - 1);
    const areas = [];
    const drawings = [];
    const walls = [];
    const notes = [];
    const journalSections = [
      `<p><strong>Size:</strong> ${sizeText}</p>`,
      `<p><strong>Themes:</strong> ${themes.join(", ")}</p>`,
      `<p><strong>Foundation:</strong> Built by a ${builder}, functioning as ${functionText}.</p>`
    ];
    const spacing = 260;

    for (let index = 0; index < count; index += 1) {
      const id = `area-${String(index + 1).padStart(2, "0")}`;
      const x = 120 + ((index % 4) * spacing);
      const y = 120 + (Math.floor(index / 4) * spacing);
      const isEntry = index === 0;
      const isUnique = !isEntry && index <= uniqueCount;

      let purpose;
      if (isEntry) {
        purpose = "Entry";
      } else if (isUnique) {
        purpose = await rollText(uniqueTableId, "Unique area");
      } else {
        const areaType = await rollText("generator-dungeon-common-area-type-0001", "Chamber");
        if (/passage/i.test(areaType)) {
          purpose = `Passage — ${await rollText("generator-dungeon-common-passage-0001", "Direct")}`;
        } else {
          const chamber = await rollText("generator-dungeon-common-chamber-0001", "No obvious purpose");
          purpose = /no obvious purpose/i.test(chamber)
            ? "Chamber — no obvious purpose"
            : `Chamber — ${await rollText("generator-dungeon-chamber-purpose-0001", "Work")}`;
        }
      }

      const areaSize = await rollText("generator-dungeon-area-size-0001", "Typical, as expected");
      const doorState = await rollText("generator-dungeon-area-door-0001", "Unlocked");
      const trapped = index > 0 && index % 4 === 0;
      const trapText = trapped ? await rollText("generator-dungeon-trap-0001", "") : null;

      areas.push({
        id, index: index + 1, labelKey: `FORGE.Scene.Area.${index + 1}`,
        displayMode: isEntry ? "public-label" : "number-only",
        shape: isEntry ? "portal" : "room",
        bounds: { x, y, width: 180, height: 120 },
        connections: index ? [`area-${String(index).padStart(2, "0")}`] : [],
        terrainTags: [themes[0] ?? "unthemed"],
        theme: isUnique ? themes[Math.min(index - 1, themes.length - 1)] : null,
        purpose,
        areaSize,
        discovered: isEntry, entered: isEntry, gmNoteUuids: [], publicNoteUuid: null,
        theatreOfMind: { defaultRangeContext: isEntry ? "near" : "far", combatLocationLabel: null, encounterRange: "near", cover: null }
      });
      drawings.push(rectangleDrawing(`drawing-${id}`, x, y, 180, 120, isEntry ? "Entry" : `${index + 1}`));
      walls.push(
        wall(`wall-${id}-top`, x, y, x + 180, y, { areaId: id }),
        wall(`wall-${id}-right`, x + 180, y, x + 180, y + 120, { areaId: id }),
        wall(`wall-${id}-bottom`, x + 180, y + 120, x, y + 120, { areaId: id }),
        wall(`wall-${id}-left`, x, y + 120, x, y, { areaId: id })
      );
      notes.push({
        id: `note-${id}`, visibility: isEntry ? "public" : "gm", noteType: "area",
        labelKey: `FORGE.Scene.Area.${index + 1}`, journalUuid: null, journalPageId: null,
        sourceGeneratorId: "dungeon", areaId: id, hexId: null, publicOnDiscovery: isEntry,
        icon: "forge.fallback.exploration", position: { x: x + 90, y: y + 60 }
      });
      if (index > 0) {
        const isSecret = index % 5 === 0;
        walls.push(wall(`door-${index}`, x - 40, y + 45, x, y + 45, { door: doorType(), secret: isSecret, areaId: id }));
        journalSections.push(`<p><strong>Area ${index + 1}</strong> (${areaSize}, door ${isSecret ? "secret" : doorState}): ${purpose}${trapText ? ` — <em>Trap:</em> ${trapText}` : ""}</p>`);
      } else {
        journalSections.push(`<p><strong>Area 1 — Entry:</strong> ${purpose}</p>`);
      }
    }

    const discoveryText = await rollText("generator-dungeon-discovery-0001", "");
    const dangerText = await rollText("generator-dungeon-danger-0001", "");
    journalSections.push(`<p><strong>Discovery seed:</strong> ${discoveryText}</p>`);
    journalSections.push(`<p><strong>Danger seed:</strong> ${dangerText}</p>`);

    return {
      name, width: 1400, height: Math.max(600, Math.ceil(count / 4) * 260),
      grid: { type: gridType("dungeon"), size: 100, distance: 5, units: "ft" },
      drawings, walls, notes,
      gmSummaryHtml: journalSections.join("\n"),
      flags: forgeFlag("dungeon", "dungeon", { seed, areas, theme: themes[0] ?? null })
    };
  }

  /** Rolls the FORGE Wilderness generation table chain and returns a scene preview. */
  static async wildernessPreview({ name = "[WILDERNESS] FORGE Wilderness", columns = 6, rows = 4, terrain = null, season = "wet", seed = null } = {}) {
    const cols = Math.max(2, Math.min(20, Number(columns) || 6));
    const rowCount = Math.max(2, Math.min(20, Number(rows) || 4));
    const startTerrain = WILDERNESS_TERRAINS.includes(terrain) ? terrain : "plains";
    const seasonKey = ["wet", "dry", "cold"].includes(season) ? season : "wet";

    const weatherText = await rollText(`generator-wilderness-weather-${seasonKey}-0001`, "Clear");
    const journalSections = [`<p><strong>Weather today (${seasonKey} season):</strong> ${weatherText}</p>`];

    const hexes = [];
    const drawings = [];
    const walls = [];
    const notes = [];
    const size = 180;
    const terrainByRow = [];

    for (let r = 0; r < rowCount; r += 1) {
      terrainByRow.push([]);
      for (let q = 0; q < cols; q += 1) {
        const id = `hex-${q}-${r}`;
        const x = 120 + (q * size) + ((r % 2) * (size / 2));
        const y = 120 + (r * 150);
        const known = q === 0 && r === 0;

        let terrainHere;
        if (known) {
          terrainHere = startTerrain;
        } else {
          const neighbourTerrain = q > 0 ? terrainByRow[r][q - 1] : terrainByRow[r - 1][cols - 1];
          const roll = await new Roll("2d6").evaluate();
          terrainHere = nextTerrain(neighbourTerrain, roll.total);
        }
        terrainByRow[r].push(terrainHere);

        const featureCategoryRoll = (await new Roll("1d6").evaluate()).total;
        const featureDetailRoll = (await new Roll("1d6").evaluate()).total;
        const feature = terrainFeature(terrainHere, featureCategoryRoll, featureDetailRoll);

        const encounterRoll = (await new Roll("1d6").evaluate()).total;
        let danger = null;
        let discovery = null;
        if (encounterRoll === 1) danger = await rollText("generator-wilderness-danger-0001", "");
        if (encounterRoll === 6) discovery = await rollText("generator-wilderness-discovery-0001", "");

        hexes.push({
          id, q, r, terrain: terrainHere, known, visited: known, weather: known ? weatherText : null,
          routes: [], features: [feature.feature], danger, discovery,
          resources: [], gmNoteUuids: [], publicLabelKey: known ? `FORGE.Scene.Hex.${q}.${r}` : null,
          theatreOfMind: { defaultRangeContext: "far", combatLocationLabel: null, encounterRange: "far", cover: null }
        });
        drawings.push(rectangleDrawing(`drawing-${id}`, x, y, size - 10, 125, known ? "Camp" : ""));
        notes.push({
          id: `note-${id}`, visibility: known ? "public" : "gm", noteType: "hex",
          labelKey: `FORGE.Scene.Hex.${q}.${r}`, journalUuid: null, journalPageId: null,
          sourceGeneratorId: "wilderness", areaId: null, hexId: id, publicOnDiscovery: known,
          icon: "forge.fallback.exploration", position: { x: x + 70, y: y + 60 }
        });
        journalSections.push(`<p><strong>Hex ${q},${r}</strong> (${terrainHere}): ${feature.category} feature — ${feature.feature}.${danger ? ` <em>Danger:</em> ${danger}.` : ""}${discovery ? ` <em>Discovery:</em> ${discovery}.` : ""}</p>`);
      }
    }
    const width = 120 + (cols * size) + size;
    const height = 200 + (rowCount * 150);
    walls.push(
      wall("wilderness-boundary-top", 60, 60, width, 60, { hexId: null }),
      wall("wilderness-boundary-bottom", 60, height, width, height, { hexId: null })
    );
    return {
      name, width, height,
      grid: { type: gridType("wilderness"), size: 100, distance: 1, units: "hex" },
      drawings, walls, notes,
      gmSummaryHtml: journalSections.join("\n"),
      flags: forgeFlag("wilderness", "wilderness", { seed, hexes, terrain: startTerrain })
    };
  }

  static async createScene(preview, { publish = false, gmOnly = true } = {}) {
    const gmSummary = preview.gmSummaryHtml ?? `<p>Generated macro map. Resolve details through FORGE theatre of mind and distance bands.</p>`;
    const gmJournal = await createJournal(`${preview.name} — GM Prep`, [{ name: "Preparation", content: `<h1>${preview.name}</h1>${gmSummary}` }], { gmOnly: true });
    const publicJournal = await createJournal(`${preview.name} — Player Reference`, [{ name: "Public Map", content: `<h1>${preview.name}</h1><p>Use FORGE distance bands and theatre of mind for detailed positioning.</p>` }], { gmOnly: false });
    const flags = foundry.utils.deepClone(preview.flags);
    flags.sceneMode = publish ? "published" : "draft";
    flags.gmSceneUuid = gmJournal.uuid;
    flags.publicJournalUuid = publicJournal.uuid;
    const sceneData = {
      name: preview.name,
      width: preview.width,
      height: preview.height,
      padding: 0.1,
      grid: preview.grid,
      tokenVision: false,
      globalLight: true,
      ownership: { default: gmOnly && !publish ? CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE : CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER },
      flags: { forge: flags }
    };
    const scene = await foundry.documents.Scene.implementation.create(sceneData);
    if (preview.drawings?.length) await scene.createEmbeddedDocuments("Drawing", preview.drawings);
    if (preview.walls?.length) await scene.createEmbeddedDocuments("Wall", preview.walls);
    const notes = preview.notes.map((note) => {
      const linkedJournal = note.visibility === "gm" ? gmJournal : publicJournal;
      const linkedPage = linkedJournal.pages?.contents?.[0] ?? null;
      return {
        _id: foundry.utils.randomID(),
        entryId: linkedJournal.id,
        pageId: linkedPage?.id ?? null,
        x: note.position.x,
        y: note.position.y,
        text: note.visibility === "gm" ? note.labelKey : "",
        icon: note.icon ?? "icons/svg/book.svg",
        flags: { forge: { ...note, journalUuid: linkedJournal.uuid, journalPageId: linkedPage?.id ?? null } }
      };
    });
    if (notes.length) await scene.createEmbeddedDocuments("Note", notes);
    return scene;
  }

  static async createDungeon(options = {}) {
    return this.createScene(await this.dungeonPreview(options), options);
  }

  static async createWilderness(options = {}) {
    return this.createScene(await this.wildernessPreview(options), options);
  }
}

export function registerForgeSceneGenerator() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.SceneGenerator = ForgeMacroSceneGenerator;
}
