/* FORGE Wilderness 2D Tables — Terrain Type (2d6, depends on the adjacent/current
 * terrain) and Terrain Feature (d6 -> Water/Plant/Land -> d6) from the FORGE
 * Anniversary Edition v1.1.2 rulebook (CC BY 4.0). These two tables key off more
 * than a single die roll, so they don't fit Foundry's linear RollTable model and
 * live here as plain data instead of compendium RollTables.
 */

export const WILDERNESS_TERRAINS = ["plains", "hills", "forest", "swamp", "desert", "mountain"];

function bucket2d6(total, ranges) {
  for (const [max, value] of ranges) if (total <= max) return value;
  return ranges[ranges.length - 1][1];
}

// Row = current/adjacent terrain; columns bucket a 2d6 roll into the resulting
// terrain of the newly entered hex. The 7-8 bucket (the most likely 2d6 outcome)
// always keeps the same terrain, matching the book's "usually stays similar" intent.
const TERRAIN_TRANSITIONS = {
  plains: [[4, "swamp"], [6, "hills"], [8, "plains"], [10, "forest"], [12, "desert"]],
  hills: [[4, "plains"], [6, "forest"], [8, "hills"], [10, "mountain"], [12, "desert"]],
  forest: [[4, "hills"], [6, "swamp"], [8, "forest"], [10, "plains"], [12, "mountain"]],
  swamp: [[4, "hills"], [6, "plains"], [8, "swamp"], [10, "forest"], [12, "mountain"]],
  desert: [[4, "forest"], [6, "hills"], [8, "desert"], [10, "plains"], [12, "mountain"]],
  mountain: [[4, "plains"], [6, "hills"], [8, "mountain"], [10, "forest"], [12, "desert"]]
};

export function nextTerrain(currentTerrain, roll2d6) {
  const ranges = TERRAIN_TRANSITIONS[currentTerrain] ?? TERRAIN_TRANSITIONS.plains;
  return bucket2d6(roll2d6, ranges);
}

function rangeTable(entries) {
  // entries: [[maxOfRange, label], ...] against a d6.
  return (roll) => bucket2d6(Math.min(roll, 6), entries);
}

// Terrain Feature (book p.33): roll d6 -> category (Water 1-2 / Plant 3-4 / Land
// 5-6) -> roll d6 again in that terrain's category table.
export const TERRAIN_FEATURES = {
  plains: {
    water: rangeTable([[1, "Lake"], [3, "Stream"], [4, "Estuary"], [5, "River"], [6, "Oxbow"]]),
    plant: rangeTable([[1, "Meadow"], [2, "Wildflowers"], [3, "Lone tree"], [4, "Long grass"], [6, "Copse"]]),
    land: rangeTable([[1, "Depression"], [2, "Bluff"], [4, "Hillock"], [5, "Ditch"], [6, "Plateau"]])
  },
  hills: {
    water: rangeTable([[1, "Waterfall"], [2, "Lake"], [3, "Fjord"], [5, "River"], [6, "Rapids"]]),
    plant: rangeTable([[1, "Thicket"], [2, "Scrub"], [3, "Copse"], [5, "Long grass"], [6, "Lone tree"]]),
    land: rangeTable([[1, "Ravine"], [3, "Valley"], [4, "Rise"], [5, "Basin"], [6, "Ridge"]])
  },
  forest: {
    water: rangeTable([[1, "Lake"], [3, "Creek"], [4, "Bog"], [5, "River"], [6, "Spring"]]),
    plant: rangeTable([[1, "Fungi"], [2, "Vines"], [4, "Dense foliage"], [5, "Raised roots"], [6, "Ancient tree"]]),
    land: rangeTable([[1, "Ditch"], [2, "Gorge"], [4, "Clearing"], [5, "Rocky area"], [6, "Hollow"]])
  },
  swamp: {
    water: rangeTable([[1, "Creek"], [2, "Delta"], [3, "Flooded area"], [4, "Pond"], [6, "Marsh"]]),
    plant: rangeTable([[2, "Fungi"], [3, "Dense flora"], [4, "Mangroves"], [5, "Tall reeds"], [6, "Willows"]]),
    land: rangeTable([[2, "Bog"], [3, "Mudflat"], [4, "Moorland"], [5, "Sinkhole"], [6, "Crossing"]])
  },
  desert: {
    water: rangeTable([[1, "Dry lakebed"], [2, "Wadi"], [3, "Salt flats"], [4, "Oasis"], [6, "Hot spring"]]),
    plant: rangeTable([[2, "Cacti"], [3, "Dry copse"], [4, "Low shrubs"], [5, "Dead shrubs"], [6, "Decrepit tree"]]),
    land: rangeTable([[2, "Dunes"], [3, "Canyon"], [4, "Dust bowl"], [5, "Mesa"], [6, "Sinkhole"]])
  },
  mountain: {
    water: rangeTable([[1, "Waterfall"], [2, "Glacier"], [3, "Rapids"], [5, "River"], [6, "Spring"]]),
    plant: rangeTable([[2, "Alpine flora"], [3, "Lone tree"], [4, "Shrubs"], [5, "Sparse grass"], [6, "Pines"]]),
    land: rangeTable([[1, "Canyon"], [2, "Crater"], [4, "Pass"], [5, "Crevasse"], [6, "Crag"]])
  }
};

export function terrainFeature(terrain, categoryRoll, detailRoll) {
  const table = TERRAIN_FEATURES[terrain] ?? TERRAIN_FEATURES.plains;
  const category = categoryRoll <= 2 ? "water" : categoryRoll <= 4 ? "plant" : "land";
  return { category, feature: table[category](detailRoll) };
}
