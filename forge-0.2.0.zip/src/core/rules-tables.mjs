/* FORGE Rules Tables — mechanical formulas transcribed from the FORGE Anniversary
 * Edition v1.1.2 rulebook by Oliver Fradgley (zap-forge.itch.io/forge), licensed
 * under Creative Commons Attribution 4.0 International. Adapted here as data/code,
 * not reproduced book text. Kept as pure data + small pure functions so every
 * formula stays centralized and auditable (mirrors the intent of ForgeRollService).
 */

// Attribute Modifiers (book p.3) — a single modifier applies to checks, saves and
// melee damage for the relevant attribute.
const ATTRIBUTE_MODIFIER_BRACKETS = [
  { max: 1, modifier: -4 },
  { max: 3, modifier: -3 },
  { max: 5, modifier: -2 },
  { max: 8, modifier: -1 },
  { max: 12, modifier: 0 },
  { max: 15, modifier: 1 },
  { max: 17, modifier: 2 },
  { max: Infinity, modifier: 3 }
];

export function attributeModifier(score) {
  const value = Number(score);
  if (!Number.isFinite(value)) return 0;
  const bracket = ATTRIBUTE_MODIFIER_BRACKETS.find((entry) => value <= entry.max);
  return bracket ? bracket.modifier : 3;
}

// Armour (book p.2). `dexCapBonus` is the maximum bonus to AC from DEX modifier
// this armour category allows; `null` means no limit.
export const ARMOUR_TABLE = {
  unarmoured: { label: "Unarmoured", baseAC: 10, slots: 0, quality: 0, dexCapBonus: null },
  leather: { label: "Leather (Light)", baseAC: 12, slots: 1, quality: 3, dexCapBonus: null },
  chain: { label: "Chain (Medium)", baseAC: 14, slots: 2, quality: 4, dexCapBonus: 2 },
  plate: { label: "Plate (Heavy)", baseAC: 16, slots: 3, quality: 5, dexCapBonus: 1, disadvantageStealth: true }
};

export const SHIELD_BONUS = { label: "Shield", acBonus: 1, slots: 1, quality: 1 };
export const HELMET = { label: "Helmet", slots: 1, quality: 1 };

export function armourClass(armourKey, dexModifier = 0, { hasShield = false } = {}) {
  const armour = ARMOUR_TABLE[armourKey] ?? ARMOUR_TABLE.unarmoured;
  const dexBonus = armour.dexCapBonus === null ? dexModifier : Math.min(dexModifier, armour.dexCapBonus);
  return armour.baseAC + Math.max(0, dexBonus) + (hasShield ? SHIELD_BONUS.acBonus : 0);
}

// Weapons (book p.2). Damage die by weapon category; roll with Advantage when a
// Medium/Heavy melee weapon is wielded two-handed (book note).
export const WEAPON_CATEGORIES = {
  unarmed: { label: "Unarmed", damage: "1d2", slots: 0, hands: 0, quality: 0, range: "close" },
  improvised: { label: "Improvised", damage: "1d4", slots: 1, hands: 1, quality: 1, range: "close" },
  lightMelee: { label: "Light melee", damage: "1d6", slots: 1, hands: 1, quality: 1, range: "close" },
  mediumMelee: { label: "Medium melee", damage: "1d8", slots: 2, hands: 1, quality: 1, range: "close", advantageTwoHanded: true },
  heavyMelee: { label: "Heavy melee", damage: "1d10", slots: 3, hands: 2, quality: 1, range: "close", advantageTwoHanded: true },
  thrown: { label: "Thrown", damage: "1d2", slots: 1, hands: 1, quality: 1, range: "far" },
  lightRanged: { label: "Light ranged", damage: "1d4", slots: 1, hands: 1, quality: 3, range: "veryFar" },
  heavyRanged: { label: "Heavy ranged", damage: "1d6", slots: 2, hands: 2, quality: 3, range: "distant" }
};

// NPC Reaction (book p.9), rolled on 2d6.
export function npcReaction(roll) {
  if (roll <= 2) return { label: "Hostile", cha: "impossible" };
  if (roll <= 5) return { label: "Unfriendly", cha: "disadvantage" };
  if (roll <= 8) return { label: "Uncertain", cha: "unmodified" };
  if (roll <= 11) return { label: "Will Talk", cha: "advantage" };
  return { label: "Helpful", cha: "success" };
}

// Turning Undead (book p.24).
export function turningUndeadOutcome(levelDifference) {
  if (levelDifference >= 3) return "destroyedOrCharmed";
  if (levelDifference >= 1) return "automaticallyTurned";
  if (levelDifference >= -1) return "checkRequired";
  return "impossible";
}
export const TURNING_UNDEAD_DURATION_TURNS = 1;

// Overland Travel — hours to cross a 6-mile hex, and encounter Risk (x-in-6),
// per terrain/road category and mode of travel (book p.8).
export const OVERLAND_TRAVEL_TABLE = {
  goodRoad: { label: "Good Road", foot: 2, horse: 1, cart: 2, risk: 0 },
  plainsTrail: { label: "Plains / Trail", foot: 3, horse: 2, cart: 4, risk: 1 },
  hillsDesert: { label: "Hills / Desert", foot: 4, horse: 3, cart: 8, risk: 2 },
  woodsForest: { label: "Woods / Forest", foot: 4, horse: null, cart: null, risk: 2 },
  swampMountain: { label: "Swamp / Mountain", foot: 8, horse: null, cart: null, risk: 3 }
};

// Resting and healing / falling (book p.8-9), small standalone formulas.
export function fallingDamageDice(feet) {
  return `${Math.max(0, Math.floor(Number(feet) / 10))}d6`;
}
export function restHealingFormula(conModifier) {
  return `1d[hd] + ${conModifier}`;
}
