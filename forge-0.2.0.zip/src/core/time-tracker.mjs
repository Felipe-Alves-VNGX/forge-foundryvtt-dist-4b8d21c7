/* FORGE Time Tracker — elapsed time is a world-level resource, not a visual label. */

// game.world is package/world metadata (foundry.packages.World), not a persisted
// Document, so it has no getFlag/setFlag. World-scoped state has to live in a
// registered world-scope setting instead.
const SETTING_NAMESPACE = "forge";
const SETTING_KEY = "timeTracker";
const DEFAULT_STATE = { day: 1, minutes: 0, phase: "day", lastEventId: null, history: [] };

export class ForgeTimeTracker {
  static get() {
    return foundry.utils.deepClone(game.settings.get(SETTING_NAMESPACE, SETTING_KEY) ?? DEFAULT_STATE);
  }

  static async advance(minutes, { reason = "manual", sourceUuid = null, actorIds = [] } = {}) {
    const current = this.get();
    const amount = Math.max(0, Number(minutes) || 0);
    const total = ((current.day - 1) * 1440) + current.minutes + amount;
    const day = Math.floor(total / 1440) + 1;
    const dayMinutes = total % 1440;
    const phase = dayMinutes >= 360 && dayMinutes < 1080 ? "day" : "night";
    const event = {
      id: foundry.utils.randomID(),
      minutes: amount,
      reason,
      sourceUuid,
      actorIds,
      createdAt: new Date().toISOString()
    };
    const next = { day, minutes: dayMinutes, phase, lastEventId: event.id, history: [...(current.history ?? []).slice(-199), event] };
    await game.settings.set(SETTING_NAMESPACE, SETTING_KEY, next);
    Hooks.callAll("forgeTimeAdvanced", event, next);
    return next;
  }

  static async postCombat() {
    return this.advance(10, { reason: "postCombat" });
  }
}

export function registerForgeTimeTracker() {
  game.settings.register(SETTING_NAMESPACE, SETTING_KEY, {
    scope: "world",
    config: false,
    type: Object,
    default: DEFAULT_STATE
  });
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.TimeTracker = ForgeTimeTracker;
}
