/*
 * FORGE — Fantasy Open Roleplaying Game Engine
 * FoundryVTT v13+ bootstrap
 */

import { ACTOR_TYPES, registerForgeDataModels } from "./src/data-models.mjs";
import { registerForgeRollService } from "./src/core/roll-service.mjs";
import { registerForgeTableRoller } from "./src/core/table-roller.mjs";
import { registerForgeConditions } from "./src/core/conditions.mjs";
import { registerForgeTimeTracker } from "./src/core/time-tracker.mjs";
import { registerForgeCombatController } from "./src/combat/forge-combat-controller.mjs";
import { ForgeMacroSceneGenerator, registerForgeSceneGenerator } from "./src/scenes/macro-scene-generator.mjs";
import { ForgeCombatTrackerApplication, registerForgeCombatTracker } from "./src/combat/forge-combat-tracker.mjs";
import { registerForgeActorSheet } from "./src/sheets/forge-actor-sheet.mjs";
import { registerForgeItemSheet } from "./src/sheets/forge-item-sheet.mjs";

const FORGE_ID = "forge";
// The running version always comes from the installed manifest (system.json via
// game.system.version) so the console/CONFIG never drift from what is actually
// installed — a hardcoded copy here previously fell out of sync across releases.
const systemPath = (relativePath) => `systems/${FORGE_ID}/${relativePath}`;
const asElement = (html) => html instanceof HTMLElement ? html : html?.[0] ?? html;

class ForgeSystem {
  static assetRegistry = null;
  static combatTracker = null;

  static async loadAssetRegistry() {
    try {
      const response = await fetch(systemPath("assets/manifests/assets.json"), { cache: "no-cache" });
      if (!response.ok) throw new Error(`Asset registry HTTP ${response.status}`);
      this.assetRegistry = await response.json();
      return this.assetRegistry;
    } catch (error) {
      this.assetRegistry = { schemaVersion: 1, assets: [], loadError: error.message };
      console.warn(`${FORGE_ID} | Asset registry unavailable; fallbacks remain active.`, error);
      return this.assetRegistry;
    }
  }

  static resolveAssetPath(path) {
    if (!path) return null;
    return /^(?:[a-z]+:|\/)/i.test(path) || path.startsWith("systems/") ? path : systemPath(path);
  }

  static resolveAsset(assetId, fallbackAssetId = null) {
    const assets = this.assetRegistry?.assets ?? [];
    const primary = assets.find((asset) => asset.assetId === assetId && asset.licenseStatus !== "blocked");
    if (primary) return this.resolveAssetPath(primary.path);
    const fallback = assets.find((asset) => asset.assetId === fallbackAssetId && asset.licenseStatus !== "blocked");
    return this.resolveAssetPath(fallback?.path);
  }

  static registerSettings() {
    game.settings.register(FORGE_ID, "automationMode", {
      name: "FORGE.Settings.AutomationMode.name",
      hint: "FORGE.Settings.AutomationMode.hint",
      scope: "world",
      config: true,
      type: String,
      choices: {
        total: "FORGE.Settings.AutomationMode.total",
        assisted: "FORGE.Settings.AutomationMode.assisted",
        manual: "FORGE.Settings.AutomationMode.manual"
      },
      default: "total"
    });

    game.settings.register(FORGE_ID, "distanceMode", {
      name: "FORGE.Settings.DistanceMode.name",
      hint: "FORGE.Settings.DistanceMode.hint",
      scope: "world",
      config: true,
      type: String,
      choices: { bands: "FORGE.Settings.DistanceMode.bands" },
      default: "bands"
    });

    game.settings.register(FORGE_ID, "assetFallbackRequired", {
      name: "FORGE.Settings.AssetFallbackRequired.name",
      hint: "FORGE.Settings.AssetFallbackRequired.hint",
      scope: "world",
      config: true,
      type: Boolean,
      default: true
    });
  }

  static registerDataModels() {
    registerForgeDataModels();
    CONFIG.Actor.trackableAttributes = Object.fromEntries(ACTOR_TYPES.map((type) => [type, {
      bar: ["resources.hp"],
      value: ["resources.morale", "level"]
    }]));
    registerForgeRollService();
    registerForgeTableRoller();
    registerForgeConditions();
    registerForgeTimeTracker();
    registerForgeCombatController();
    registerForgeSceneGenerator();
    registerForgeCombatTracker();
    CONFIG.FORGE = CONFIG.FORGE ?? {};
    CONFIG.FORGE.systemId = FORGE_ID;
    CONFIG.FORGE.version = game.system.version;
    CONFIG.FORGE.distanceBands = ["close", "near", "far", "veryFar", "distant"];
  }

  static registerSheets() {
    registerForgeActorSheet();
    registerForgeItemSheet();
  }

  static addForgeButton(container, { label, icon, className, onClick }) {
    if (!container || container.querySelector(`[data-forge-button="${className}"]`)) return;
    const button = document.createElement("button");
    button.type = "button";
    button.className = `forge-directory-button ${className}`;
    button.dataset.forgeButton = className;
    button.innerHTML = `<i class="${icon}"></i><span>${label}</span>`;
    button.addEventListener("click", onClick);
    const header = container.querySelector(".directory-header, .header-actions, header") ?? container;
    header.append(button);
  }

  static registerVisibleEntrypoints() {
    Hooks.on("renderApplicationV2", (app, html) => {
      const root = asElement(html);
      if (!root || !game.user?.isGM) return;
      const applicationId = app?.options?.id ?? app?.id ?? "";
      const applicationName = app?.constructor?.name ?? "";
      const isCombatTracker = applicationId === "combat" || applicationName === "CombatTracker";
      const isSceneDirectory = applicationId === "scenes" || applicationName === "SceneDirectory";
      if (isCombatTracker) {
        this.addForgeButton(root, {
          label: game.i18n.localize("FORGE.EntryPoints.Tracker"),
          icon: "fas fa-fire",
          className: "forge-open-combat-tracker",
          onClick: () => ForgeCombatTrackerApplication.open()
        });
        root.dataset.forgePresentation = "available";
      }
      if (isSceneDirectory) {
        this.addForgeButton(root, {
          label: game.i18n.localize("FORGE.EntryPoints.Dungeon"),
          icon: "fas fa-dungeon",
          className: "forge-generate-dungeon",
          onClick: async () => {
            const preview = await ForgeMacroSceneGenerator.dungeonPreview();
            await ForgeMacroSceneGenerator.createScene(preview, { publish: false, gmOnly: true });
            ui.notifications.info(game.i18n.localize("FORGE.Notifications.DungeonCreated"));
          }
        });
        this.addForgeButton(root, {
          label: game.i18n.localize("FORGE.EntryPoints.Wilderness"),
          icon: "fas fa-mountain-sun",
          className: "forge-generate-wilderness",
          onClick: async () => {
            const preview = await ForgeMacroSceneGenerator.wildernessPreview();
            await ForgeMacroSceneGenerator.createScene(preview, { publish: false, gmOnly: true });
            ui.notifications.info(game.i18n.localize("FORGE.Notifications.WildernessCreated"));
          }
        });
      }
    });
  }

  static registerHooks() {
    Hooks.on("renderChatMessageHTML", (message, html) => {
      const root = asElement(html);
      if (root) root.dataset.forge = "true";
    });

    Hooks.on("updateCombat", (combat, changes, options, userId) => {
      if (!combat.flags?.forge) return;
      Hooks.callAll("forgeCombatStateChanged", combat, changes, options, userId);
    });

    this.registerVisibleEntrypoints();
  }
}

Hooks.once("init", async () => {
  await foundry.applications.handlebars.loadTemplates([
    systemPath("templates/combat-tracker.hbs"),
    systemPath("templates/actor-sheet.hbs"),
    systemPath("templates/item-sheet.hbs")
  ]);
  ForgeSystem.registerDataModels();
  ForgeSystem.registerSettings();
  ForgeSystem.registerSheets();
  ForgeSystem.registerHooks();
  console.info(`${FORGE_ID} | Initializing FORGE ${game.system.version} for FoundryVTT v13+.`);
});


Hooks.once("ready", async () => {
  await ForgeSystem.loadAssetRegistry();
  game.forge = ForgeSystem;
  console.info(`${FORGE_ID} | Ready. Automation=${game.settings.get(FORGE_ID, "automationMode")}.`);
});

export { ForgeSystem };
