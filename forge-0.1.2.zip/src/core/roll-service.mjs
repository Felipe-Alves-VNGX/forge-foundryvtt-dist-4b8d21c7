/* FORGE Roll Service — formulas remain centralized and auditable. */

const ATTRIBUTE_ALIASES = { STR: "str", DEX: "dex", CON: "con", INT: "int", WIS: "wis", CHA: "cha" };

export class ForgeRollService {
  static attributeKey(attribute) {
    const key = String(attribute ?? "").trim();
    return ATTRIBUTE_ALIASES[key.toUpperCase()] ?? key.toLowerCase();
  }

  static getAttribute(actor, attribute) {
    const key = this.attributeKey(attribute);
    const data = actor?.system?.attributes?.[key];
    if (!data) throw new Error(`Unknown FORGE attribute: ${attribute}`);
    return { key, ...data };
  }

  static formulaForAttribute(actor, attribute, { advantage = 0 } = {}) {
    const attr = this.getAttribute(actor, attribute);
    const dice = advantage > 0 ? "2d20kh" : advantage < 0 ? "2d20kl" : "1d20";
    return { formula: `${dice} + ${attr.checkBonus ?? 0}`, attribute: attr.key, checkBonus: attr.checkBonus ?? 0 };
  }

  static async attributeCheck(actor, attribute, { advantage = 0, target = 15, flavor = null, speaker = null } = {}) {
    const context = this.formulaForAttribute(actor, attribute, { advantage });
    const roll = await new Roll(context.formula).evaluate();
    const natural = roll.dice?.[0]?.results?.map((result) => result.result) ?? [];
    const naturalOne = natural.includes(1);
    const naturalTwenty = natural.includes(20);
    const success = naturalTwenty || (!naturalOne && roll.total >= target);
    const result = { ...context, target, total: roll.total, success, naturalOne, naturalTwenty, formula: context.formula };
    await this.toChat(roll, { ...result, actor, flavor, speaker });
    return result;
  }

  static async opposed(actor, defender, attribute, { target = null, advantage = 0, flavor = null } = {}) {
    const attacker = await this.attributeCheck(actor, attribute, {
      advantage,
      target: target ?? (10 + (this.getAttribute(defender, attribute).checkBonus ?? 0)),
      flavor
    });
    return { attacker, defender: defender?.name ?? null, opposed: true };
  }

  static async toChat(roll, { actor = null, flavor = null, speaker = null, ...context } = {}) {
    const content = await roll.render();
    const messageData = {
      speaker: speaker ?? ChatMessage.getSpeaker({ actor }),
      flavor: flavor ?? "FORGE Roll",
      content,
      flags: { forge: { rollContext: context } }
    };
    return ChatMessage.create(messageData);
  }
}

export function registerForgeRollService() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.RollService = ForgeRollService;
}
