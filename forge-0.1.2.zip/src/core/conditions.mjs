/* FORGE Conditions — declarative definitions for ActiveEffect adapters and workflows. */

export const FORGE_CONDITIONS = {
  encumbered: { labelKey: "FORGE.Conditions.encumbered", icon: "forge.icon.condition.encumbered", movement: "near", predicates: ["movementReduced"] },
  overloaded: { labelKey: "FORGE.Conditions.overloaded", icon: "forge.icon.condition.overloaded", movement: "close", predicates: ["movementReduced", "cannotRun"] },
  exhausted: { labelKey: "FORGE.Conditions.exhausted", icon: "forge.icon.condition.exhausted", predicates: ["disadvantageChecks"] },
  unconscious: { labelKey: "FORGE.Conditions.unconscious", icon: "forge.icon.condition.unconscious", turnEligibility: "skip", predicates: ["helpless"] },
  dead: { labelKey: "FORGE.Conditions.dead", icon: "forge.icon.condition.dead", turnEligibility: "skip", predicates: ["helpless", "cannotAct"] },
  poisoned: { labelKey: "FORGE.Conditions.poisoned", icon: "forge.icon.condition.poisoned", saves: true, predicates: ["poisonCounter"] },
  diseased: { labelKey: "FORGE.Conditions.diseased", icon: "forge.icon.condition.diseased", predicates: ["diseaseSave"] },
  blinded: { labelKey: "FORGE.Conditions.blinded", icon: "forge.icon.condition.blinded", predicates: ["disadvantageAttacks", "cannotSee"] },
  paralyzed: { labelKey: "FORGE.Conditions.paralyzed", icon: "forge.icon.condition.paralyzed", turnEligibility: "skip", predicates: ["helpless"] },
  petrified: { labelKey: "FORGE.Conditions.petrified", icon: "forge.icon.condition.petrified", turnEligibility: "skip", predicates: ["helpless"] },
  charmed: { labelKey: "FORGE.Conditions.charmed", icon: "forge.icon.condition.charmed", predicates: ["socialInfluence"] },
  confused: { labelKey: "FORGE.Conditions.confused", icon: "forge.icon.condition.confused", predicates: ["randomTarget"] },
  invisible: { labelKey: "FORGE.Conditions.invisible", icon: "forge.icon.condition.invisible", predicates: ["advantageAttacks", "hiddenFromNormalSight"] },
  asleep: { labelKey: "FORGE.Conditions.asleep", icon: "forge.icon.condition.asleep", turnEligibility: "skip", predicates: ["helpless"] },
  held: { labelKey: "FORGE.Conditions.held", icon: "forge.icon.condition.held", turnEligibility: "held", predicates: ["cannotMove"] },
  energyDrain: { labelKey: "FORGE.Conditions.energyDrain", icon: "forge.icon.condition.energy-drain", predicates: ["levelReduction"] },
  fleeing: { labelKey: "FORGE.Conditions.fleeing", icon: "forge.icon.condition.fleeing", turnEligibility: "fleeing", predicates: ["moveMaximum", "cannotAttackUnlessCornered"] },
  defeated: { labelKey: "FORGE.Conditions.defeated", icon: "forge.icon.condition.defeated", turnEligibility: "skip", predicates: ["helpless"] }
};

export function conditionDefinition(conditionId) {
  return FORGE_CONDITIONS[conditionId] ?? null;
}

export function hasCondition(actor, conditionId) {
  return Boolean(actor?.system?.conditions?.includes(conditionId));
}

export function evaluateTurnEligibility(actor) {
  const conditions = actor?.system?.conditions ?? [];
  if (conditions.some((id) => FORGE_CONDITIONS[id]?.turnEligibility === "fleeing")) return { state: "fleeing", reason: "fleeing" };
  if (conditions.some((id) => FORGE_CONDITIONS[id]?.turnEligibility === "held")) return { state: "held", reason: "held" };
  const skip = conditions.find((id) => ["skip", "unconscious"].includes(FORGE_CONDITIONS[id]?.turnEligibility));
  if (skip) return { state: "skip", reason: skip };
  return { state: "eligible", reason: null };
}

export async function applyCondition(actor, conditionId, { duration = null, sourceUuid = null, stack = false } = {}) {
  const definition = conditionDefinition(conditionId);
  if (!definition) throw new Error(`Unknown FORGE condition: ${conditionId}`);
  const current = actor.system.conditions ?? [];
  if (!stack && current.includes(conditionId)) return actor;
  const conditions = [...current, conditionId];
  await actor.update({ "system.conditions": conditions, "flags.forge.lastConditionSource": sourceUuid, "flags.forge.lastConditionDuration": duration });
  return actor;
}

export async function removeCondition(actor, conditionId) {
  const conditions = (actor.system.conditions ?? []).filter((id) => id !== conditionId);
  await actor.update({ "system.conditions": conditions });
  return actor;
}

export function registerForgeConditions() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.conditions = FORGE_CONDITIONS;
  CONFIG.FORGE.evaluateTurnEligibility = evaluateTurnEligibility;
}
