/* FORGE Time Tracker — elapsed time is a world-level resource, not a visual label. */

export class ForgeTimeTracker {
  static get(world) {
    return foundry.utils.deepClone(world.getFlag("forge", "timeTracker") ?? {
      day: 1,
      minutes: 0,
      phase: "day",
      lastEventId: null,
      history: []
    });
  }

  static async advance(minutes, { reason = "manual", sourceUuid = null, actorIds = [] } = {}) {
    const current = this.get(game.world);
    const amount = Math.max(0, Number(minutes) || 0);
    const total = ((current.day - 1) * 1440) + current.minutes + amount;
    const day = Math.floor(total / 1440) + 1;
    const dayMinutes = total % 1440;
    const phase = dayMinutes >= 360 && dayMinutes < 1080 ? "day" : "night";
    const event = {
      id: foundry.utils.randomID(),
      minutes: amount,
      reason,
      sourceUuid,
      actorIds,
      createdAt: new Date().toISOString()
    };
    const next = { day, minutes: dayMinutes, phase, lastEventId: event.id, history: [...(current.history ?? []).slice(-199), event] };
    await game.world.setFlag("forge", "timeTracker", next);
    Hooks.callAll("forgeTimeAdvanced", event, next);
    return next;
  }

  static async postCombat() {
    return this.advance(10, { reason: "postCombat" });
  }
}

export function registerForgeTimeTracker() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.TimeTracker = ForgeTimeTracker;
}
