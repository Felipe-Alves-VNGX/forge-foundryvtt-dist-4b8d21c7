/* FORGE DataModels — FoundryVTT v13+ */

export const ACTOR_TYPES = ["character", "creature", "hireling", "mercenary", "companion", "animal", "force", "settlement"];
export const ITEM_TYPES = [
  "weapon", "armor", "shield", "helmet", "equipment", "tool", "spell", "scroll", "consumable", "poison",
  "magicItem", "vehicle", "property", "follower", "naturalAttack", "treasure", "quest", "injury"
];

const fields = () => foundry.data.fields;
const nullableString = () => new (fields().StringField)({ nullable: true, initial: null });
const attributeSchema = () => new (fields().SchemaField)({
  value: new (fields().NumberField)({ integer: true, initial: 10, min: 1, max: 20 }),
  checkBonus: new (fields().NumberField)({ integer: true, initial: 0 }),
  saveBonus: new (fields().NumberField)({ integer: true, initial: 0 }),
  damageBonus: new (fields().NumberField)({ integer: true, initial: 0 })
});

export class ForgeActorDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const f = fields();
    return {
      identity: new f.SchemaField({
        ancestry: new f.StringField({ initial: "human" }),
        occupation: new f.StringField({ initial: "" }),
        alignment: new f.StringField({ initial: "neutral" }),
        description: new f.StringField({ initial: "" }),
        portraitAssetId: nullableString()
      }),
      level: new f.NumberField({ integer: true, initial: 1, min: 0, max: 20 }),
      experience: new f.NumberField({ initial: 0, min: 0 }),
      attributes: new f.SchemaField({
        str: attributeSchema(),
        dex: attributeSchema(),
        con: attributeSchema(),
        int: attributeSchema(),
        wis: attributeSchema(),
        cha: attributeSchema()
      }),
      resources: new f.SchemaField({
        hp: new f.SchemaField({ value: new f.NumberField({ integer: true, initial: 1, min: 0 }), max: new f.NumberField({ integer: true, initial: 1, min: 0 }) }),
        hd: new f.NumberField({ initial: 1, min: 0 }),
        morale: new f.NumberField({ initial: 7, min: 0, max: 20 }),
        luck: new f.NumberField({ initial: 0 }),
        karma: new f.NumberField({ initial: 0 }),
        fatigue: new f.NumberField({ integer: true, initial: 0, min: 0 }),
        energyDrain: new f.NumberField({ integer: true, initial: 0, min: 0 })
      }),
      defense: new f.SchemaField({
        armorClass: new f.NumberField({ integer: true, initial: 10 }),
        dexCap: new f.NumberField({ integer: true, initial: null, nullable: true }),
        movementBand: new f.StringField({ initial: "near" }),
        savingThrow: new f.NumberField({ integer: true, initial: 15 })
      }),
      inventory: new f.SchemaField({
        slotCapacity: new f.NumberField({ initial: 10, min: 0 }),
        extraSlots: new f.NumberField({ initial: 0, min: 0 }),
        usedSlots: new f.NumberField({ initial: 0, min: 0 }),
        encumbrance: new f.StringField({ initial: "normal", choices: ["normal", "encumbered", "overloaded"] })
      }),
      conditions: new f.ArrayField(new f.StringField(), { initial: [] }),
      effects: new f.ArrayField(new f.StringField(), { initial: [] }),
      paragon: new f.SchemaField({
        enabled: new f.BooleanField({ initial: false }),
        luck: new f.NumberField({ integer: true, initial: 0 }),
        luckyDay: new f.BooleanField({ initial: false })
      }),
      forge: new f.SchemaField({
        stableId: new f.StringField({ initial: "" }),
        subtype: new f.StringField({ initial: "" }),
        assetId: nullableString(),
        fallbackAssetId: nullableString(),
        notes: new f.StringField({ initial: "" })
      })
    };
  }

  prepareDerivedData() {
    const hp = this.resources?.hp ?? { value: 0, max: 0 };
    this.resources.hp.value = Math.max(0, Math.min(hp.value, hp.max));
    const capacity = Math.max(0, (this.inventory?.slotCapacity ?? 0) + (this.inventory?.extraSlots ?? 0));
    const used = Math.max(0, this.inventory?.usedSlots ?? 0);
    this.inventory.encumbrance = used > capacity ? "overloaded" : used > (capacity / 2) ? "encumbered" : "normal";
    this.defense.movementBand = this.inventory.encumbrance === "overloaded" ? "close" : this.inventory.encumbrance === "encumbered" ? "near" : "near";
  }
}

export class ForgeItemDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const f = fields();
    return {
      quantity: new f.NumberField({ integer: true, initial: 1, min: 0 }),
      weightSlots: new f.NumberField({ initial: 0, min: 0 }),
      price: new f.NumberField({ initial: 0, min: 0 }),
      equipped: new f.BooleanField({ initial: false }),
      quality: new f.NumberField({ integer: true, initial: 3, min: 0, max: 5 }),
      actionCost: new f.StringField({ initial: "manual", choices: ["free", "movement", "minor", "main", "reaction", "manual"] }),
      activation: new f.SchemaField({
        usable: new f.BooleanField({ initial: false }),
        charges: new f.NumberField({ integer: true, initial: 0, min: 0 }),
        maxCharges: new f.NumberField({ integer: true, initial: 0, min: 0 }),
        recharge: nullableString()
      }),
      effectId: nullableString(),
      automation: new f.SchemaField({
        enabled: new f.BooleanField({ initial: true }),
        workflowId: nullableString(),
        overridePolicy: new f.StringField({ initial: "prompt", choices: ["block", "prompt", "allow"] })
      }),
      forge: new f.SchemaField({
        stableId: new f.StringField({ initial: "" }),
        assetId: nullableString(),
        fallbackAssetId: nullableString(),
        sourcePage: new f.NumberField({ integer: true, initial: null, nullable: true, min: 1 }),
        tags: new f.ArrayField(new f.StringField(), { initial: [] })
      })
    };
  }
}

export function registerForgeDataModels() {
  if (!globalThis.CONFIG?.Actor?.dataModels || !globalThis.CONFIG?.Item?.dataModels) {
    console.warn("forge | Foundry DataModel configuration is unavailable; registration deferred.");
    return;
  }
  for (const type of ACTOR_TYPES) CONFIG.Actor.dataModels[type] = ForgeActorDataModel;
  for (const type of ITEM_TYPES) CONFIG.Item.dataModels[type] = ForgeItemDataModel;
}
