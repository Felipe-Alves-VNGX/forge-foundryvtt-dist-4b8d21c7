/* FORGE Item Sheet — FoundryVTT v13+ ItemSheetV2 */

const itemTypes = [
  "weapon", "armor", "shield", "helmet", "equipment", "tool", "spell", "scroll", "consumable", "poison",
  "magicItem", "vehicle", "property", "follower", "naturalAttack", "treasure", "quest", "injury"
];
const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ItemSheetV2 } = foundry.applications.sheets;

export class ForgeItemSheet extends HandlebarsApplicationMixin(ItemSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["forge", "forge-item-sheet"],
    position: { width: 640, height: 620 },
    window: { resizable: true, icon: "fas fa-toolbox" },
    tag: "form",
    form: {
      handler: ForgeItemSheet._onSubmitForm,
      submitOnChange: true,
      closeOnSubmit: false
    },
    actions: {
      useItem: ForgeItemSheet._onUseItem
    }
  };

  static PARTS = {
    form: {
      template: "systems/forge/templates/item-sheet.hbs",
      classes: ["forge-sheet-body"],
      scrollable: [".forge-sheet-body"]
    }
  };

  get title() {
    return `${this.item.name} — FORGE`;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const system = this.item.system ?? {};
    return {
      ...context,
      item: this.item,
      system,
      editable: this.isEditable,
      assetPath: game.forge?.resolveAsset?.(system.forge?.assetId, system.forge?.fallbackAssetId)
        ?? "icons/svg/item-bag.svg",
      actionCostLabel: system.actionCost ?? "manual",
      chargesVisible: (system.activation?.maxCharges ?? 0) > 0
    };
  }

  static async _onSubmitForm(event, form, formData) {
    event.preventDefault();
    if (!this.isEditable) return;
    await this.item.update(formData.object);
  }

  static async _onUseItem(event, target) {
    event.preventDefault();
    const actor = this.actor;
    if (!actor) return ui.notifications.warn("FORGE: coloque o Item em um Actor antes de usá-lo.");
    const actionCost = this.item.system?.actionCost ?? "manual";
    const charges = this.item.system?.activation?.charges ?? 0;
    const maxCharges = this.item.system?.activation?.maxCharges ?? 0;
    if (maxCharges > 0 && charges <= 0) return ui.notifications.warn("FORGE: nenhuma carga restante.");
    if (maxCharges > 0) {
      await this.item.update({ "system.activation.charges": Math.max(0, charges - 1) });
    }
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<p><strong>${foundry.utils.escapeHTML(this.item.name)}</strong> usado.</p><p>Custo de ação: ${foundry.utils.escapeHTML(actionCost)}.</p>`,
      flags: { forge: { workflow: "item-use", itemId: this.item.id, actionCost } }
    });
  }
}

export function registerForgeItemSheet() {
  const collection = foundry.documents.collections.Items;
  if (!collection?.registerSheet) {
    console.warn("forge | Item sheet registry is unavailable in Foundry v13.");
    return false;
  }
  collection.registerSheet("forge", ForgeItemSheet, {
    types: itemTypes,
    makeDefault: true,
    label: "FORGE.Sheets.Item.label",
    canConfigure: true
  });
  return true;
}
