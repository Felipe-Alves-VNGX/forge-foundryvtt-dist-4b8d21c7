/* FORGE Actor Sheet — FoundryVTT v13+ ActorSheetV2 */

const actorTypes = ["character", "creature", "hireling", "mercenary", "companion", "animal", "force", "settlement"];
const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

export class ForgeActorSheet extends HandlebarsApplicationMixin(ActorSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["forge", "forge-actor-sheet"],
    position: { width: 900, height: 760 },
    window: { resizable: true, icon: "fas fa-user-shield" },
    tag: "form",
    form: {
      handler: ForgeActorSheet._onSubmitForm,
      submitOnChange: false,
      closeOnSubmit: false
    },
    actions: {
      rollAttribute: ForgeActorSheet._onRollAttribute,
      toggleItem: ForgeActorSheet._onToggleItem
    }
  };

  static PARTS = {
    form: {
      template: "systems/forge/templates/actor-sheet.hbs",
      classes: ["forge-sheet-body"],
      scrollable: [".forge-sheet-body"]
    }
  };

  get title() {
    return `${this.actor.name} — FORGE`;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const system = this.actor.system ?? {};
    const attributes = Object.entries(system.attributes ?? {}).map(([key, value]) => ({
      key,
      label: `FORGE.Attributes.${key}`,
      value: value.value ?? 0,
      checkBonus: value.checkBonus ?? 0,
      saveBonus: value.saveBonus ?? 0,
      damageBonus: value.damageBonus ?? 0
    }));
    const items = this.actor.items.contents.map((item) => ({
      id: item.id,
      name: item.name,
      type: item.type,
      quantity: item.system?.quantity ?? 1,
      equipped: Boolean(item.system?.equipped),
      icon: item.img ?? "icons/svg/item-bag.svg"
    }));

    return {
      ...context,
      actor: this.actor,
      system,
      attributes,
      items,
      conditions: system.conditions ?? [],
      hpPercent: system.resources?.hp?.max
        ? Math.round((system.resources.hp.value / system.resources.hp.max) * 100)
        : 0,
      assetPath: game.forge?.resolveAsset?.(system.forge?.assetId, system.forge?.fallbackAssetId)
        ?? "icons/svg/mystery-man.svg",
      editable: this.isEditable
    };
  }

  static async _onSubmitForm(event, form, formData) {
    event.preventDefault();
    if (!this.isEditable) return;
    await this.actor.update(formData.object);
  }

  static async _onRollAttribute(event, target) {
    event.preventDefault();
    const attribute = target.dataset.attribute;
    const service = CONFIG.FORGE?.RollService;
    if (!service) return ui.notifications.warn("FORGE Roll Service is not ready.");
    await service.attributeCheck(this.actor, attribute, {
      flavor: `${this.actor.name} — ${attribute.toUpperCase()}`
    });
  }

  static async _onToggleItem(event, target) {
    event.preventDefault();
    if (!this.isEditable) return;
    const item = this.actor.items.get(target.dataset.itemId);
    if (item) await item.update({ "system.equipped": !item.system.equipped });
  }
}

export function registerForgeActorSheet() {
  const collection = foundry.documents.collections.Actors;
  if (!collection?.registerSheet) {
    console.warn("forge | Actor sheet registry is unavailable in Foundry v13.");
    return false;
  }
  collection.registerSheet("forge", ForgeActorSheet, {
    types: actorTypes,
    makeDefault: true,
    label: "FORGE.Sheets.Actor.label",
    canConfigure: true
  });
  return true;
}
