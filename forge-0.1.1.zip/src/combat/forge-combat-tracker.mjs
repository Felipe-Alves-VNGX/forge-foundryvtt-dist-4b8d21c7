/* FORGE Combat Tracker — ApplicationV2 presentation layer. */

import { ForgeCombatController } from "./forge-combat-controller.mjs";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class ForgeCombatTrackerApplication extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "forge-combat-tracker",
    classes: ["forge", "forge-combat-tracker"],
    tag: "section",
    position: { width: 380, height: 620 },
    window: { title: "FORGE Combat", resizable: true, icon: "fas fa-fire" },
    actions: {
      nextTurn: ForgeCombatTrackerApplication._onNextTurn,
      endCombat: ForgeCombatTrackerApplication._onEndCombat,
      resolveMorale: ForgeCombatTrackerApplication._onResolveMorale
    }
  };

  static PARTS = {
    body: {
      template: "systems/forge/templates/combat-tracker.hbs",
      classes: ["forge-combat-tracker-body"],
      scrollable: [".forge-combat-body"]
    }
  };

  static open() {
    const application = new this();
    application.render(true);
    return application;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const combat = game.combat;
    if (!combat) return { ...context, hasCombat: false, title: game.i18n.localize("FORGE.Combat.noCombat") };

    const state = foundry.utils.deepClone(combat.getFlag("forge", "combatState") ?? {});
    const sides = Object.values(state.sides ?? {}).map((side) => ({
      ...side,
      combatants: combat.combatants.filter((combatant) => state.combatants?.[combatant.id]?.sideId === side.id).map((combatant) => ({
        id: combatant.id,
        name: combatant.name,
        img: combatant.token?.texture?.src ?? combatant.actor?.prototypeToken?.texture?.src ?? null,
        defeated: combatant.isDefeated,
        current: combat.current?.id === combatant.id,
        state: state.combatants?.[combatant.id] ?? {}
      }))
    }));

    return {
      ...context,
      hasCombat: true,
      title: combat.name,
      round: combat.round ?? 0,
      phase: state.phase ?? "setup",
      activeSide: state.activeSide ?? null,
      sideSequence: state.sideSequence ?? [],
      sides,
      automationMode: game.settings.get("forge", "automationMode"),
      userIsGM: game.user.isGM,
      distanceMode: state.distanceMode ?? "bands"
    };
  }

  static async _onNextTurn(event) {
    event?.preventDefault();
    const combat = game.combat;
    if (!combat || !game.user.isGM) return;
    const current = combat.current?.id;
    if (current) await ForgeCombatController.useAction(combat, current, { kind: "endTurn", cost: "main", description: "Tracker end turn" });
    await combat.nextTurn();
    this.render();
  }

  static async _onEndCombat(event) {
    event?.preventDefault();
    if (game.combat && game.user.isGM) await ForgeCombatController.endCombat(game.combat);
    this.render();
  }

  static async _onResolveMorale(event) {
    event?.preventDefault();
    if (game.combat && game.user.isGM) await ForgeCombatController.moraleReview(game.combat);
    this.render();
  }
}

export function registerForgeCombatTracker() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.CombatTrackerApplication = ForgeCombatTrackerApplication;
  CONFIG.FORGE.openCombatTracker = () => ForgeCombatTrackerApplication.open();
  Hooks.on("renderCombatTracker", (_app, html) => {
    const root = html instanceof HTMLElement ? html : html?.[0] ?? html;
    if (root) root.dataset.forgePresentation = "available";
  });
}
