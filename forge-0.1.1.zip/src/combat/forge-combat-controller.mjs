/*
 * FORGE Combat Controller
 * The native Combat document remains the synchronization layer; this controller owns FORGE state.
 */

import { ForgeRollService } from "../core/roll-service.mjs";
import { ForgeTimeTracker } from "../core/time-tracker.mjs";
import { evaluateTurnEligibility } from "../core/conditions.mjs";

const DEFAULT_STATE = {
  schemaVersion: 3,
  mode: "forge-sides",
  distanceMode: "bands",
  phase: "setup",
  activeSide: null,
  sideSequence: [],
  roundStartSide: null,
  initiative: { mode: "side", status: "pending", groupFormula: "1d20 + CHA", soloFormula: "1d20 + DEX", rolls: {}, tieBreak: "manual" },
  ambush: { status: "none", attackingSide: null, surprisedSide: null, openingCombatantId: null, resolvedAt: null },
  sides: {},
  combatants: {},
  morale: {},
  revision: 0,
  operationId: null,
  needsReconcile: false,
  audit: []
};

function clone(value) {
  return foundry.utils.deepClone(value);
}

function ensureState(combat) {
  return foundry.utils.mergeObject(clone(DEFAULT_STATE), clone(combat.getFlag("forge", "combatState") ?? {}), { inplace: false, recursive: true });
}

function now() {
  return new Date().toISOString();
}

function operationId() {
  return foundry.utils.randomID();
}

export class ForgeCombatController {
  static async prepare(combat, { sides = [], ambush = null } = {}) {
    const state = ensureState(combat);
    state.mode = "forge-sides";
    state.phase = "setup";
    state.sides = Object.fromEntries(sides.map((side) => [side.id, {
      id: side.id,
      name: side.name ?? side.id,
      leaderUuid: side.leaderUuid ?? null,
      leaderAttribute: side.leaderAttribute ?? "cha",
      isSolo: Boolean(side.isSolo),
      morale: Number(side.morale ?? 7),
      status: "ready",
      completed: false
    }]));
    state.sideSequence = sides.map((side) => side.id);
    state.roundStartSide = sides[0]?.id ?? null;
    state.activeSide = sides[0]?.id ?? null;
    state.ambush = ambush ? {
      status: "ambushPending",
      attackingSide: ambush.attackingSide ?? null,
      surprisedSide: ambush.surprisedSide ?? null,
      openingCombatantId: ambush.openingCombatantId ?? null,
      resolvedAt: null
    } : clone(DEFAULT_STATE.ambush);
    for (const combatant of combat.combatants) {
      const existing = state.combatants[combatant.id] ?? {};
      state.combatants[combatant.id] = {
        sideId: existing.sideId ?? null,
        isSolo: Boolean(existing.isSolo),
        turnState: "waiting",
        turnEligibility: "eligible",
        skipReason: null,
        movement: { available: true, spent: false, band: "near", remainingBand: "near", run: false, engaged: false, minorActionReducedMovement: false },
        minorAction: { available: true, spent: false },
        mainAction: { available: true, spent: false },
        hold: { active: false, trigger: null, action: null, actionId: null, targetUuids: [], rangeBand: "manual", validUntil: "currentTurn", expiresAt: null, onExpire: "lost", createdBy: null, resolved: false },
        morale: { checkedThisRound: false, pending: false, trigger: null, triggers: [], rollFormula: null, result: null, outcome: null, checkedRound: null, freeAttackEventId: null },
        interventionRequired: false,
        ...existing
      };
    }
    return this.commit(combat, state, { event: "combatPrepared" });
  }

  static async resolveInitiative(combat, { rerollTies = true } = {}) {
    const state = ensureState(combat);
    const sides = Object.values(state.sides);
    if (sides.length < 2) throw new Error("FORGE combat requires at least two sides");
    if (state.ambush.status === "ambushPending") {
      state.phase = "initiative";
      state.initiative.status = "pending";
      return this.commit(combat, state, { event: "initiativeDeferredForAmbush" });
    }

    const rolls = {};
    for (const side of sides) {
      const leader = side.leaderUuid ? fromUuidSync(side.leaderUuid) : null;
      const attribute = side.isSolo ? "dex" : (side.leaderAttribute ?? "cha");
      const actor = leader?.actor ?? leader;
      const result = actor ? await ForgeRollService.attributeCheck(actor, attribute, { target: 0, flavor: `FORGE Initiative — ${side.name}` }) : { total: 0, formula: `1d20 + ${attribute}`, success: true };
      rolls[side.id] = {
        formula: side.isSolo ? "1d20 + DEX check bonus" : "1d20 + CHA check bonus",
        total: result.total,
        attribute,
        leaderUuid: side.leaderUuid,
        target: null
      };
    }

    const groups = new Map();
    for (const side of sides) {
      const total = rolls[side.id].total;
      if (!groups.has(total)) groups.set(total, []);
      groups.get(total).push(side.id);
    }
    if (rerollTies) {
      for (const tied of groups.values()) {
        if (tied.length < 2) continue;
        for (const sideId of tied) {
          const result = await new Roll("1d20").evaluate();
          rolls[sideId].tieReroll = result.total;
        }
      }
    }

    state.sideSequence = sides.slice().sort((a, b) => {
      const aScore = rolls[a.id].tieReroll ?? rolls[a.id].total;
      const bScore = rolls[b.id].tieReroll ?? rolls[b.id].total;
      return bScore - aScore || a.name.localeCompare(b.name);
    }).map((side) => side.id);
    state.activeSide = state.sideSequence[0];
    state.roundStartSide = state.activeSide;
    state.initiative = { ...state.initiative, status: "resolved", rolls, winnerSide: state.activeSide, sideSequence: clone(state.sideSequence) };
    state.phase = "sideAction";
    await this.syncNativeInitiative(combat, state);
    return this.commit(combat, state, { event: "sideInitiativeResolved" });
  }

  static async resolveAmbush(combat, { confirm = true } = {}) {
    const state = ensureState(combat);
    if (state.ambush.status !== "ambushPending") return state;
    if (!confirm) return state;
    state.ambush.status = "openingAttack";
    state.phase = "sideAction";
    state.activeSide = state.ambush.attackingSide;
    await this.commit(combat, state, { event: "ambushOpeningAttack" });
    state.ambush.status = "resolved";
    state.ambush.resolvedAt = now();
    await this.resolveInitiative(combat, { rerollTies: true });
    return this.commit(combat, state, { event: "ambushResolved" });
  }

  static async syncNativeInitiative(combat, state) {
    const sidePriority = new Map(state.sideSequence.map((sideId, index) => [sideId, index]));
    const updates = [];
    for (const combatant of combat.combatants) {
      const data = state.combatants[combatant.id];
      const actor = combatant.actor;
      const dex = actor?.system?.attributes?.dex?.value ?? 10;
      const score = Math.max(0, Math.min(999, 100 + dex));
      updates.push({ _id: combatant.id, initiative: ((sidePriority.get(data?.sideId) ?? 999) * 1000) + score });
    }
    if (updates.length) await combat.updateEmbeddedDocuments("Combatant", updates, { forgeOperation: "syncNativeInitiative" });
  }

  static getEligibility(combatant) {
    const actor = combatant.actor;
    if (!actor) return { state: "unassigned", reason: "missingActor" };
    const result = evaluateTurnEligibility(actor);
    return result.state === "eligible" && !combatant.isDefeated ? result : { state: result.state === "eligible" ? "skip" : result.state, reason: result.reason ?? "defeated" };
  }

  static async startTurn(combat, combatantId) {
    const state = ensureState(combat);
    const combatant = combat.combatants.get(combatantId);
    if (!combatant) throw new Error(`Unknown Combatant ${combatantId}`);
    const eligibility = this.getEligibility(combatant);
    const current = state.combatants[combatantId] ?? {};
    state.combatants[combatantId] = {
      ...current,
      turnState: eligibility.state === "eligible" ? "active" : eligibility.state,
      turnEligibility: eligibility.state,
      skipReason: eligibility.reason,
      movement: { ...current.movement, available: eligibility.state === "eligible", spent: false, remainingBand: current.movement?.band ?? "near" },
      minorAction: { available: eligibility.state === "eligible", spent: false },
      mainAction: { available: eligibility.state === "eligible", spent: false },
      hold: { ...current.hold, resolved: false }
    };
    state.phase = "sideAction";
    return this.commit(combat, state, { event: "turnStarted", combatantId });
  }

  static async useAction(combat, combatantId, { kind, actionId = null, cost = kind, description = "" } = {}) {
    const state = ensureState(combat);
    const data = state.combatants[combatantId];
    if (!data) throw new Error(`Unknown FORGE combatant state ${combatantId}`);
    if (data.turnEligibility !== "eligible") throw new Error(`Combatant is not eligible: ${data.turnEligibility}`);
    if (cost === "movement") data.movement = { ...data.movement, available: false, spent: true };
    if (cost === "minor") data.minorAction = { ...data.minorAction, available: false, spent: true };
    if (cost === "main") data.mainAction = { ...data.mainAction, available: false, spent: true };
    const event = { id: operationId(), combatantId, kind, actionId, cost, description, createdAt: now() };
    state.audit = [...(state.audit ?? []).slice(-199), { event: "actionUsed", ...event }];
    return this.commit(combat, state, { event: "actionUsed", combatantId, action: event });
  }

  static async createHold(combat, combatantId, payload) {
    const state = ensureState(combat);
    const data = state.combatants[combatantId];
    if (!data?.mainAction?.available) throw new Error("Hold requires an available Main Action");
    data.mainAction = { ...data.mainAction, available: false, spent: true };
    data.hold = {
      active: true,
      trigger: payload.trigger ?? "manual",
      action: payload.action ?? null,
      actionId: payload.actionId ?? null,
      targetUuids: payload.targetUuids ?? [],
      rangeBand: payload.rangeBand ?? "manual",
      validUntil: payload.validUntil ?? "currentTurn",
      expiresAt: payload.expiresAt ?? null,
      onExpire: payload.onExpire ?? "lost",
      createdBy: game.user.id,
      resolved: false
    };
    return this.commit(combat, state, { event: "holdCreated", combatantId });
  }

  static async expireHolds(combat) {
    const state = ensureState(combat);
    for (const data of Object.values(state.combatants)) {
      if (!data.hold?.active) continue;
      if (data.hold.validUntil !== "manual") data.hold = { ...data.hold, active: false, resolved: true };
    }
    return this.commit(combat, state, { event: "holdsExpired" });
  }

  static async moraleReview(combat) {
    const state = ensureState(combat);
    const pending = [];
    for (const [sideId, side] of Object.entries(state.sides)) {
      const triggers = Object.values(state.combatants).flatMap((data) => data.sideId === sideId ? (data.morale?.triggers ?? []) : []);
      if (!triggers.length || side.morale == null) continue;
      const roll = await new Roll("2d6").evaluate();
      const outcome = roll.total > side.morale ? "fleeing" : "hold";
      state.morale[sideId] = { sideId, rollFormula: "2d6", result: roll.total, target: side.morale, outcome, checkedRound: combat.round };
      pending.push({ sideId, outcome, result: roll.total, target: side.morale });
    }
    state.phase = "roundEnd";
    await this.commit(combat, state, { event: "moraleReview", pending });
    return pending;
  }

  static async endCombat(combat) {
    const state = ensureState(combat);
    await ForgeTimeTracker.postCombat();
    state.phase = "ended";
    await this.commit(combat, state, { event: "combatEnded" });
    return combat.endCombat();
  }

  static async commit(combat, state, { event, ...detail } = {}) {
    const previousRevision = Number(combat.getFlag("forge", "combatState.revision") ?? 0);
    state.revision = previousRevision + 1;
    state.operationId = operationId();
    state.audit = [...(state.audit ?? []).slice(-199), { event, ...detail, operationId: state.operationId, revision: state.revision, createdAt: now() }];
    await combat.setFlag("forge", "combatState", state);
    Hooks.callAll("forgeCombatStateChanged", combat, state, event);
    return state;
  }
}

export function registerForgeCombatController() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.CombatController = ForgeCombatController;
}
