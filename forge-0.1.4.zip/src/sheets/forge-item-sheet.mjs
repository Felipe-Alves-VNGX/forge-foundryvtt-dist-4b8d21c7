/* FORGE Item Sheet — FoundryVTT v13+ ItemSheetV2 */

const itemTypes = [
  "weapon", "armor", "shield", "helmet", "equipment", "tool", "spell", "scroll", "consumable", "poison",
  "magicItem", "vehicle", "property", "follower", "naturalAttack", "treasure", "quest", "injury"
];
const itemTabs = ["details", "effects", "automation"];
const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ItemSheetV2 } = foundry.applications.sheets;

function localize(key, fallback) {
  const value = game.i18n.localize(key);
  return value === key ? fallback : value;
}

function collectFormValues(form) {
  const data = {};
  for (const element of Array.from(form.elements ?? [])) {
    if (!element?.name || element.disabled) continue;
    const type = String(element.type ?? "").toLowerCase();
    if (["submit", "button", "reset", "file"].includes(type)) continue;
    let value;
    if (type === "checkbox") value = Boolean(element.checked);
    else if (type === "number") {
      if (element.value === "") continue;
      const numeric = Number(element.value);
      value = Number.isNaN(numeric) ? element.value : numeric;
    } else value = element.value;
    foundry.utils.setProperty(data, element.name, value);
  }
  return data;
}

export class ForgeItemSheet extends HandlebarsApplicationMixin(ItemSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["forge", "forge-item-sheet"],
    position: { width: 680, height: 680 },
    window: { resizable: true, icon: "fas fa-toolbox" },
    tag: "form",
    form: {
      handler: ForgeItemSheet._onSubmitForm,
      submitOnChange: true,
      closeOnSubmit: false
    },
    actions: {
      useItem: ForgeItemSheet._onUseItem,
      changeTab: ForgeItemSheet._onChangeTab,
      saveSheet: ForgeItemSheet._onSaveSheet
    }
  };

  static PARTS = {
    form: {
      template: "systems/forge/templates/item-sheet.hbs",
      classes: ["forge-sheet-body"],
      scrollable: [".forge-sheet-body"]
    }
  };

  constructor(options = {}) {
    super(options);
    this._activeTab = "details";
  }

  get title() {
    return `${this.item.name} — FORGE`;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const system = this.item.system ?? {};
    const activeTab = itemTabs.includes(this._activeTab) ? this._activeTab : "details";
    return {
      ...context,
      item: this.item,
      system,
      tabs: Object.fromEntries(itemTabs.map((tab) => [tab, tab === activeTab])),
      labels: {
        details: localize("FORGE.Sheets.ItemTabs.details", "Details"),
        effects: localize("FORGE.Sheets.ItemTabs.effects", "Effects"),
        automation: localize("FORGE.Sheets.ItemTabs.automation", "Automation"),
        itemDetails: localize("FORGE.Sheets.itemDetails", "Item Details"),
        activation: localize("FORGE.Sheets.activation", "Activation"),
        save: localize("FORGE.Sheets.save", "Save Changes"),
        use: localize("FORGE.Sheets.use", "Use Item"),
        effectId: localize("FORGE.Sheets.effectId", "Effect ID")
      },
      editable: this.isEditable,
      assetPath: game.forge?.resolveAsset?.(system.forge?.assetId, system.forge?.fallbackAssetId)
        ?? "icons/svg/item-bag.svg",
      actionCostLabel: localize(`FORGE.ActionCost.${system.actionCost ?? "manual"}`, system.actionCost ?? "manual"),
      chargesVisible: (system.activation?.maxCharges ?? 0) > 0
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    this._setActiveTab(this._activeTab);
  }

  _setActiveTab(tab) {
    this._activeTab = itemTabs.includes(tab) ? tab : "details";
    const root = this.element;
    if (!root) return;
    for (const panel of root.querySelectorAll("[data-forge-tab-panel]")) {
      const visible = panel.dataset.forgeTabPanel === this._activeTab;
      panel.hidden = !visible;
      panel.classList.toggle("active", visible);
    }
    for (const button of root.querySelectorAll("[data-forge-tab-button]")) {
      const active = button.dataset.tab === this._activeTab;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", String(active));
    }
  }

  static async _onSubmitForm(event, form) {
    event.preventDefault();
    if (!this.isEditable) return;
    const updateData = collectFormValues(form);
    try {
      await this.document.update(updateData);
    } catch (error) {
      console.error("forge | Item sheet update failed", error, updateData);
      ui.notifications.error("FORGE: não foi possível salvar a ficha do Item.");
      throw error;
    }
  }

  static async _onSaveSheet(event) {
    event.preventDefault();
    if (!this.isEditable) return;
    await this.submit();
  }

  static _onChangeTab(event, target) {
    event.preventDefault();
    this._setActiveTab(target.dataset.tab);
  }

  static async _onUseItem(event) {
    event.preventDefault();
    const actor = this.item.actor ?? this.actor ?? null;
    if (!actor) return ui.notifications.warn("FORGE: coloque o Item em um Actor antes de usá-lo.");
    const actionCost = this.item.system?.actionCost ?? "manual";
    const charges = this.item.system?.activation?.charges ?? 0;
    const maxCharges = this.item.system?.activation?.maxCharges ?? 0;
    const usable = this.item.system?.activation?.usable ?? false;
    if (!usable) return ui.notifications.warn("FORGE: este Item está marcado como não utilizável.");
    if (maxCharges > 0 && charges <= 0) return ui.notifications.warn("FORGE: nenhuma carga restante.");
    if (maxCharges > 0) {
      await this.item.update({ "system.activation.charges": Math.max(0, charges - 1) });
    }
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<p><strong>${foundry.utils.escapeHTML(this.item.name)}</strong> usado.</p><p>Custo de ação: ${foundry.utils.escapeHTML(actionCost)}.</p>`,
      flags: { forge: { workflow: "item-use", itemId: this.item.id, actionCost } }
    });
  }
}

export function registerForgeItemSheet() {
  const collection = foundry.documents.collections.Items;
  if (!collection?.registerSheet) {
    console.warn("forge | Item sheet registry is unavailable in Foundry v13.");
    return false;
  }
  collection.registerSheet("forge", ForgeItemSheet, {
    types: itemTypes,
    makeDefault: true,
    label: "FORGE.Sheets.Item.label",
    canConfigure: true
  });
  return true;
}
