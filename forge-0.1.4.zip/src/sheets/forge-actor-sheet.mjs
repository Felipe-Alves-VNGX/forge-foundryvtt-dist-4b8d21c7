/* FORGE Actor Sheet — FoundryVTT v13+ ActorSheetV2 */

const actorTypes = ["character", "creature", "hireling", "mercenary", "companion", "animal", "force", "settlement"];
const actorTabs = ["attributes", "inventory", "conditions", "notes"];
const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

function localize(key, fallback) {
  const value = game.i18n.localize(key);
  return value === key ? fallback : value;
}

function applyCheckboxValues(form, data) {
  for (const input of form.querySelectorAll('input[type="checkbox"][name]')) {
    foundry.utils.setProperty(data, input.name, input.checked);
  }
  return data;
}

export class ForgeActorSheet extends HandlebarsApplicationMixin(ActorSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["forge", "forge-actor-sheet"],
    position: { width: 900, height: 760 },
    window: { resizable: true, icon: "fas fa-user-shield" },
    tag: "form",
    form: {
      handler: ForgeActorSheet._onSubmitForm,
      submitOnChange: true,
      closeOnSubmit: false
    },
    actions: {
      rollAttribute: ForgeActorSheet._onRollAttribute,
      toggleItem: ForgeActorSheet._onToggleItem,
      changeTab: ForgeActorSheet._onChangeTab,
      saveSheet: ForgeActorSheet._onSaveSheet
    }
  };

  static PARTS = {
    form: {
      template: "systems/forge/templates/actor-sheet.hbs",
      classes: ["forge-sheet-body"],
      scrollable: [".forge-sheet-body"]
    }
  };

  constructor(options = {}) {
    super(options);
    this._activeTab = "attributes";
  }

  get title() {
    return `${this.actor.name} — FORGE`;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const system = this.actor.system ?? {};
    const activeTab = actorTabs.includes(this._activeTab) ? this._activeTab : "attributes";
    const attributes = Object.entries(system.attributes ?? {}).map(([key, value]) => ({
      key,
      label: localize(`FORGE.Attributes.${key}`, key.toUpperCase()),
      value: value?.value ?? 0,
      checkBonus: value?.checkBonus ?? 0,
      saveBonus: value?.saveBonus ?? 0,
      damageBonus: value?.damageBonus ?? 0
    }));
    const items = this.actor.items.contents.map((item) => ({
      id: item.id,
      name: item.name,
      type: item.type,
      quantity: item.system?.quantity ?? 1,
      equipped: Boolean(item.system?.equipped),
      icon: item.img ?? "icons/svg/item-bag.svg"
    }));
    const conditions = (system.conditions ?? []).map((condition) => ({
      key: condition,
      label: localize(`FORGE.Conditions.${condition}`, condition)
    }));

    return {
      ...context,
      actor: this.actor,
      system,
      attributes,
      items,
      conditions,
      tabs: Object.fromEntries(actorTabs.map((tab) => [tab, tab === activeTab])),
      labels: {
        attributes: localize("FORGE.Sheets.Tabs.attributes", "Attributes"),
        inventory: localize("FORGE.Sheets.Tabs.inventory", "Inventory"),
        conditions: localize("FORGE.Sheets.Tabs.conditions", "Conditions"),
        notes: localize("FORGE.Sheets.Tabs.notes", "Notes"),
        resources: localize("FORGE.Sheets.resources", "Resources"),
        save: localize("FORGE.Sheets.save", "Save Changes"),
        noItems: localize("FORGE.Sheets.noItems", "No items yet."),
        noConditions: localize("FORGE.Sheets.noConditions", "No active conditions."),
        notesHint: localize("FORGE.Sheets.notesHint", "GM notes and actor-specific references")
      },
      hpPercent: system.resources?.hp?.max
        ? Math.round((system.resources.hp.value / system.resources.hp.max) * 100)
        : 0,
      assetPath: game.forge?.resolveAsset?.(system.forge?.assetId, system.forge?.fallbackAssetId)
        ?? "icons/svg/mystery-man.svg",
      editable: this.isEditable
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    this._setActiveTab(this._activeTab);
  }

  _setActiveTab(tab) {
    this._activeTab = actorTabs.includes(tab) ? tab : "attributes";
    const root = this.element;
    if (!root) return;
    for (const panel of root.querySelectorAll("[data-forge-tab-panel]")) {
      const visible = panel.dataset.forgeTabPanel === this._activeTab;
      panel.hidden = !visible;
      panel.classList.toggle("active", visible);
    }
    for (const button of root.querySelectorAll("[data-forge-tab-button]")) {
      const active = button.dataset.tab === this._activeTab;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", String(active));
    }
  }

  static async _onSubmitForm(event, form, formData) {
    event.preventDefault();
    if (!this.isEditable) return;
    const updateData = foundry.utils.deepClone(formData.object);
    applyCheckboxValues(form, updateData);
    await this.actor.update(updateData);
  }

  static async _onSaveSheet(event) {
    event.preventDefault();
    if (!this.isEditable) return;
    await this.submit();
  }

  static _onChangeTab(event, target) {
    event.preventDefault();
    this._setActiveTab(target.dataset.tab);
  }

  static async _onRollAttribute(event, target) {
    event.preventDefault();
    const attribute = target.dataset.attribute;
    const service = CONFIG.FORGE?.RollService;
    if (!service) return ui.notifications.warn("FORGE Roll Service is not ready.");
    await service.attributeCheck(this.actor, attribute, {
      flavor: `${this.actor.name} — ${attribute.toUpperCase()}`
    });
  }

  static async _onToggleItem(event, target) {
    event.preventDefault();
    if (!this.isEditable) return;
    const item = this.actor.items.get(target.dataset.itemId);
    if (item) await item.update({ "system.equipped": !item.system.equipped });
  }
}

export function registerForgeActorSheet() {
  const collection = foundry.documents.collections.Actors;
  if (!collection?.registerSheet) {
    console.warn("forge | Actor sheet registry is unavailable in Foundry v13.");
    return false;
  }
  collection.registerSheet("forge", ForgeActorSheet, {
    types: actorTypes,
    makeDefault: true,
    label: "FORGE.Sheets.Actor.label",
    canConfigure: true
  });
  return true;
}
