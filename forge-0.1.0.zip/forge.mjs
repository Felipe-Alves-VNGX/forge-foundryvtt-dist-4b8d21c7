/*
 * FORGE — Fantasy Open Roleplaying Game Engine
 * FoundryVTT v13+ bootstrap
 */

import { registerForgeDataModels } from "./src/data-models.mjs";
import { registerForgeRollService } from "./src/core/roll-service.mjs";
import { registerForgeConditions } from "./src/core/conditions.mjs";
import { registerForgeTimeTracker } from "./src/core/time-tracker.mjs";
import { registerForgeCombatController } from "./src/combat/forge-combat-controller.mjs";
import { registerForgeSceneGenerator } from "./src/scenes/macro-scene-generator.mjs";
import { registerForgeCombatTracker } from "./src/combat/forge-combat-tracker.mjs";
import { registerForgeActorSheet } from "./src/sheets/forge-actor-sheet.mjs";
import { registerForgeItemSheet } from "./src/sheets/forge-item-sheet.mjs";

const FORGE_ID = "forge";
const FORGE_VERSION = "0.1.0";

class ForgeSystem {
  static assetRegistry = null;

  static async loadAssetRegistry() {
    try {
      const response = await fetch("assets/manifests/assets.json", { cache: "no-cache" });
      if (!response.ok) throw new Error(`Asset registry HTTP ${response.status}`);
      this.assetRegistry = await response.json();
      return this.assetRegistry;
    } catch (error) {
      this.assetRegistry = { schemaVersion: 1, assets: [], loadError: error.message };
      console.warn(`${FORGE_ID} | Asset registry unavailable; fallbacks remain active.`, error);
      return this.assetRegistry;
    }
  }

  static resolveAsset(assetId, fallbackAssetId = null) {
    const assets = this.assetRegistry?.assets ?? [];
    const primary = assets.find((asset) => asset.assetId === assetId && asset.licenseStatus !== "blocked");
    if (primary) return primary.path;
    const fallback = assets.find((asset) => asset.assetId === fallbackAssetId && asset.licenseStatus !== "blocked");
    return fallback?.path ?? null;
  }

  static registerSettings() {
    game.settings.register(FORGE_ID, "automationMode", {
      name: "FORGE.Settings.AutomationMode.name",
      hint: "FORGE.Settings.AutomationMode.hint",
      scope: "world",
      config: true,
      type: String,
      choices: {
        total: "FORGE.Settings.AutomationMode.total",
        assisted: "FORGE.Settings.AutomationMode.assisted",
        manual: "FORGE.Settings.AutomationMode.manual"
      },
      default: "total"
    });

    game.settings.register(FORGE_ID, "distanceMode", {
      name: "FORGE.Settings.DistanceMode.name",
      hint: "FORGE.Settings.DistanceMode.hint",
      scope: "world",
      config: true,
      type: String,
      choices: { bands: "FORGE.Settings.DistanceMode.bands" },
      default: "bands"
    });

    game.settings.register(FORGE_ID, "assetFallbackRequired", {
      name: "FORGE.Settings.AssetFallbackRequired.name",
      hint: "FORGE.Settings.AssetFallbackRequired.hint",
      scope: "world",
      config: true,
      type: Boolean,
      default: true
    });
  }

  static registerDataModels() {
    registerForgeDataModels();
    registerForgeRollService();
    registerForgeConditions();
    registerForgeTimeTracker();
    registerForgeCombatController();
    registerForgeSceneGenerator();
    registerForgeCombatTracker();
    registerForgeActorSheet();
    registerForgeItemSheet();
    CONFIG.FORGE = CONFIG.FORGE ?? {};
    CONFIG.FORGE.systemId = FORGE_ID;
    CONFIG.FORGE.version = FORGE_VERSION;
    CONFIG.FORGE.distanceBands = ["close", "near", "far", "veryFar", "distant"];
  }

  static registerHooks() {
    Hooks.on("renderChatMessageHTML", (message, html) => {
      html.dataset.forge = "true";
    });

    Hooks.on("updateCombat", (combat, changes, options, userId) => {
      if (!combat.flags?.forge) return;
      Hooks.callAll("forgeCombatStateChanged", combat, changes, options, userId);
    });
  }
}

Hooks.once("init", async () => {
  await loadTemplates([
    "systems/forge/templates/combat-tracker.hbs",
    "systems/forge/templates/actor-sheet.hbs",
    "systems/forge/templates/item-sheet.hbs"
  ]);
  ForgeSystem.registerDataModels();
  ForgeSystem.registerSettings();
  ForgeSystem.registerHooks();
  console.info(`${FORGE_ID} | Initializing FORGE ${FORGE_VERSION} for FoundryVTT v13+.`);
});

Hooks.once("ready", async () => {
  await ForgeSystem.loadAssetRegistry();
  game.forge = ForgeSystem;
  console.info(`${FORGE_ID} | Ready. Automation=${game.settings.get(FORGE_ID, "automationMode")}.`);
});

export { ForgeSystem };
