/* FORGE Actor Sheet — FoundryVTT v13+ ApplicationV2 */

const actorTypes = ["character", "creature", "hireling", "mercenary", "companion", "animal", "force", "settlement"];
const ApplicationV2 = foundry.applications.api.ApplicationV2;
const HandlebarsMixin = foundry.applications.api.HandlebarsApplicationMixin;

export class ForgeActorSheet extends HandlebarsMixin(ApplicationV2) {
  constructor(actor, options = {}) {
    super(options);
    this.actor = actor;
  }

  static DEFAULT_OPTIONS = {
    id: "forge-actor-sheet-{id}",
    classes: ["forge", "forge-actor-sheet"],
    position: { width: 900, height: 760 },
    window: { resizable: true }
  };

  static PARTS = {
    form: {
      template: "systems/forge/templates/actor-sheet.hbs",
      scrollable: [".forge-sheet-body"]
    }
  };

  get title() {
    return `${this.actor.name} — FORGE`;
  }

  async _prepareContext() {
    const system = this.actor.system ?? {};
    const attributes = Object.entries(system.attributes ?? {}).map(([key, value]) => ({
      key,
      label: `FORGE.Attributes.${key}`,
      value: value.value ?? 0,
      checkBonus: value.checkBonus ?? 0,
      saveBonus: value.saveBonus ?? 0,
      damageBonus: value.damageBonus ?? 0
    }));
    const items = this.actor.items.contents.map((item) => ({
      id: item.id,
      name: item.name,
      type: item.type,
      quantity: item.system?.quantity ?? 1,
      equipped: Boolean(item.system?.equipped),
      icon: item.img ?? "icons/svg/item-bag.svg"
    }));
    return {
      actor: this.actor,
      system,
      attributes,
      items,
      conditions: system.conditions ?? [],
      hpPercent: system.resources?.hp?.max ? Math.round((system.resources.hp.value / system.resources.hp.max) * 100) : 0,
      assetPath: globalThis.game?.forge?.resolveAsset?.(system.forge?.assetId, system.forge?.fallbackAssetId) ?? "icons/svg/mystery-man.svg",
      editable: this.actor.isOwner
    };
  }

  _onRender(context, options) {
    const root = this.element;
    root.querySelectorAll("[data-action='roll-attribute']").forEach((button) => {
      button.addEventListener("click", () => {
        const attribute = button.dataset.attribute;
        const service = CONFIG.FORGE?.RollService;
        if (!service) return ui.notifications.warn("FORGE Roll Service is not ready.");
        service.attributeCheck(this.actor, attribute, { flavor: `${this.actor.name} — ${attribute.toUpperCase()}` });
      });
    });

    root.querySelectorAll("[data-field-path]").forEach((input) => {
      input.addEventListener("change", async (event) => {
        if (!this.actor.isOwner) return;
        const path = event.currentTarget.dataset.fieldPath;
        const value = event.currentTarget.type === "number" ? Number(event.currentTarget.value) : event.currentTarget.value;
        await this.actor.update({ [path]: value });
      });
    });

    root.querySelectorAll("[data-action='toggle-item']").forEach((button) => {
      button.addEventListener("click", async () => {
        const item = this.actor.items.get(button.dataset.itemId);
        if (item) await item.update({ "system.equipped": !item.system.equipped });
      });
    });
  }

  static register() {
    if (!globalThis.Actors?.registerSheet) return;
    Actors.registerSheet("forge", ForgeActorSheet, {
      types: actorTypes,
      makeDefault: true,
      label: "FORGE.Sheets.Actor.label",
      canConfigure: true
    });
  }
}

export function registerForgeActorSheet() {
  ForgeActorSheet.register();
}
