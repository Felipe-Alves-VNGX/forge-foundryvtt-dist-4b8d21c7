/* FORGE Item Sheet — FoundryVTT v13+ ApplicationV2 */

const itemTypes = [
  "weapon", "armor", "shield", "helmet", "equipment", "tool", "spell", "scroll", "consumable", "poison",
  "magicItem", "vehicle", "property", "follower", "naturalAttack", "treasure", "quest", "injury"
];
const ApplicationV2 = foundry.applications.api.ApplicationV2;
const HandlebarsMixin = foundry.applications.api.HandlebarsApplicationMixin;

export class ForgeItemSheet extends HandlebarsMixin(ApplicationV2) {
  constructor(item, options = {}) {
    super(options);
    this.item = item;
  }

  static DEFAULT_OPTIONS = {
    id: "forge-item-sheet-{id}",
    classes: ["forge", "forge-item-sheet"],
    position: { width: 640, height: 620 },
    window: { resizable: true }
  };

  static PARTS = {
    form: {
      template: "systems/forge/templates/item-sheet.hbs",
      scrollable: [".forge-sheet-body"]
    }
  };

  get title() {
    return `${this.item.name} — FORGE`;
  }

  async _prepareContext() {
    const system = this.item.system ?? {};
    return {
      item: this.item,
      system,
      editable: this.item.isOwner,
      assetPath: globalThis.game?.forge?.resolveAsset?.(system.forge?.assetId, system.forge?.fallbackAssetId) ?? "icons/svg/item-bag.svg",
      actionCostLabel: system.actionCost ?? "manual",
      chargesVisible: (system.activation?.maxCharges ?? 0) > 0
    };
  }

  _onRender(context, options) {
    const root = this.element;
    root.querySelectorAll("[data-field-path]").forEach((input) => {
      input.addEventListener("change", async (event) => {
        if (!this.item.isOwner) return;
        const path = event.currentTarget.dataset.fieldPath;
        const value = event.currentTarget.type === "checkbox" ? event.currentTarget.checked : Number(event.currentTarget.value);
        await this.item.update({ [path]: value });
      });
    });

    root.querySelectorAll("[data-action='use-item']").forEach((button) => {
      button.addEventListener("click", async () => {
        const actor = this.item.parent;
        if (!actor) return ui.notifications.warn("FORGE: place the Item on an Actor before using it.");
        const actionCost = this.item.system?.actionCost ?? "manual";
        const charges = this.item.system?.activation?.charges ?? 0;
        const maxCharges = this.item.system?.activation?.maxCharges ?? 0;
        if (maxCharges > 0 && charges <= 0) return ui.notifications.warn("FORGE: no charges remaining.");
        const updates = maxCharges > 0 ? { "system.activation.charges": Math.max(0, charges - 1) } : {};
        if (Object.keys(updates).length) await this.item.update(updates);
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `<p><strong>${this.item.name}</strong> used.</p><p>Action cost: ${actionCost}.</p>`,
          flags: { forge: { workflow: "item-use", itemId: this.item.id, actionCost } }
        });
      });
    });
  }

  static register() {
    if (!globalThis.Items?.registerSheet) return;
    Items.registerSheet("forge", ForgeItemSheet, {
      types: itemTypes,
      makeDefault: true,
      label: "FORGE.Sheets.Item.label",
      canConfigure: true
    });
  }
}

export function registerForgeItemSheet() {
  ForgeItemSheet.register();
}
