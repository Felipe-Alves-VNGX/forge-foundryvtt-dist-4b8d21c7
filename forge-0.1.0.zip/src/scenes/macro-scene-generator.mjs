/* FORGE Macro Scene Generator — abstract, interactive, non-tactical maps. */

const forgeFlag = (kind, generatorId, extra = {}) => ({
  schemaVersion: 3,
  sceneKind: kind,
  sceneMode: "draft",
  distanceMode: "bands",
  visibilityPolicy: "public-with-gm-private-notes",
  generatorId,
  seed: foundry.utils.randomID(),
  areas: [],
  hexes: [],
  connections: [],
  notes: [],
  wallRefs: [],
  doorRefs: [],
  discovery: {},
  lastAreaId: null,
  lastHexId: null,
  publicSceneUuid: null,
  gmSceneUuid: null,
  reconcile: { status: "clean", lastRun: null, conflicts: [] },
  ...extra
});

const gridType = (kind) => {
  if (kind === "wilderness") return CONST.GRID_TYPES.HEXODDR ?? CONST.GRID_TYPES.HEXODDQ ?? 2;
  return CONST.GRID_TYPES.GRIDLESS ?? 0;
};

const wallNormal = () => CONST.WALL_RESTRICTION_TYPES?.NORMAL ?? 1;
const doorType = () => CONST.WALL_DOOR_TYPES?.DOOR ?? 1;
const doorClosed = () => CONST.WALL_DOOR_STATES?.CLOSED ?? 0;

function rectangleDrawing(id, x, y, width, height, label = "") {
  return {
    _id: id,
    x,
    y,
    shape: { type: CONST.DRAWING_TYPES?.RECTANGLE ?? "r", width, height },
    fillType: 1,
    fillColor: "#637D4F",
    fillAlpha: 0.16,
    strokeWidth: 2,
    strokeColor: "#A85C32",
    text: label,
    fontSize: 18,
    flags: { forge: { generated: true, stableId: id } }
  };
}

function wall(id, x1, y1, x2, y2, { door = 0, secret = false, areaId = null, hexId = null } = {}) {
  return {
    _id: id,
    c: [x1, y1, x2, y2],
    move: wallNormal(),
    sense: wallNormal(),
    light: wallNormal(),
    sound: wallNormal(),
    door,
    ds: door ? doorClosed() : 0,
    flags: { forge: { generated: true, stableId: id, secret, areaId, hexId } }
  };
}

async function gmJournal(name, pages) {
  return JournalEntry.create({
    name,
    ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE },
    pages: pages.map((page, index) => ({
      name: page.name ?? `Page ${index + 1}`,
      type: "text",
      text: { format: 1, content: page.content ?? "" },
      ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE }
    })),
    flags: { forge: { generated: true, gmOnly: true } }
  });
}

export class ForgeMacroSceneGenerator {
  static dungeonPreview({ name = "[DUNGEON] FORGE Dungeon", areaCount = 6, theme = "unknown", seed = null } = {}) {
    const count = Math.max(2, Math.min(36, Number(areaCount) || 6));
    const areas = [];
    const drawings = [];
    const walls = [];
    const notes = [];
    const spacing = 260;
    for (let index = 0; index < count; index += 1) {
      const id = `area-${String(index + 1).padStart(2, "0")}`;
      const x = 120 + ((index % 4) * spacing);
      const y = 120 + (Math.floor(index / 4) * spacing);
      areas.push({ id, index: index + 1, labelKey: `FORGE.Scene.Area.${index + 1}`, displayMode: index === 0 ? "public-label" : "number-only", shape: index === 0 ? "portal" : "room", bounds: { x, y, width: 180, height: 120 }, connections: index ? [`area-${String(index).padStart(2, "0")}`] : [], terrainTags: [theme], discovered: index === 0, entered: index === 0, gmNoteUuids: [], publicNoteUuid: null, theatreOfMind: { defaultRangeContext: index === 0 ? "near" : "far", combatLocationLabel: null, encounterRange: "near", cover: null } });
      drawings.push(rectangleDrawing(`drawing-${id}`, x, y, 180, 120, index === 0 ? "Entry" : `${index + 1}`));
      walls.push(wall(`wall-${id}-top`, x, y, x + 180, y, { areaId: id }), wall(`wall-${id}-right`, x + 180, y, x + 180, y + 120, { areaId: id }), wall(`wall-${id}-bottom`, x + 180, y + 120, x, y + 120, { areaId: id }), wall(`wall-${id}-left`, x, y + 120, x, y, { areaId: id }));
      notes.push({ id: `note-${id}`, visibility: index === 0 ? "public" : "gm", noteType: "area", labelKey: `FORGE.Scene.Area.${index + 1}`, journalUuid: null, journalPageId: null, sourceGeneratorId: "dungeon", areaId: id, hexId: null, publicOnDiscovery: index === 0, icon: "forge.fallback.exploration", position: { x: x + 90, y: y + 60 } });
      if (index > 0) walls.push(wall(`door-${index}`, x - 40, y + 45, x, y + 45, { door: doorType(), secret: index % 5 === 0, areaId: id }));
    }
    return { name, width: 1400, height: Math.max(600, Math.ceil(count / 4) * 260), grid: { type: gridType("dungeon"), size: 100, distance: 5, units: "ft" }, drawings, walls, notes, flags: forgeFlag("dungeon", "dungeon", { seed, areas }) };
  }

  static wildernessPreview({ name = "[WILDERNESS] FORGE Wilderness", columns = 6, rows = 4, terrain = "wilderness", seed = null } = {}) {
    const cols = Math.max(2, Math.min(20, Number(columns) || 6));
    const rowCount = Math.max(2, Math.min(20, Number(rows) || 4));
    const hexes = [];
    const drawings = [];
    const walls = [];
    const notes = [];
    const size = 180;
    for (let r = 0; r < rowCount; r += 1) {
      for (let q = 0; q < cols; q += 1) {
        const id = `hex-${q}-${r}`;
        const x = 120 + (q * size) + ((r % 2) * (size / 2));
        const y = 120 + (r * 150);
        const known = q === 0 && r === 0;
        hexes.push({ id, q, r, terrain, known, visited: known, weather: null, routes: [], features: [], danger: null, discovery: null, resources: [], gmNoteUuids: [], publicLabelKey: known ? `FORGE.Scene.Hex.${q}.${r}` : null, theatreOfMind: { defaultRangeContext: "far", combatLocationLabel: null, encounterRange: "far", cover: null } });
        drawings.push(rectangleDrawing(`drawing-${id}`, x, y, size - 10, 125, known ? "Camp" : ""));
        notes.push({ id: `note-${id}`, visibility: known ? "public" : "gm", noteType: "hex", labelKey: `FORGE.Scene.Hex.${q}.${r}`, journalUuid: null, journalPageId: null, sourceGeneratorId: "wilderness", areaId: null, hexId: id, publicOnDiscovery: known, icon: "forge.fallback.exploration", position: { x: x + 70, y: y + 60 } });
      }
    }
    const width = 120 + (cols * size) + size;
    const height = 200 + (rowCount * 150);
    walls.push(wall("wilderness-boundary-top", 60, 60, width, 60, { hexId: null }), wall("wilderness-boundary-bottom", 60, height, width, height, { hexId: null }));
    return { name, width, height, grid: { type: gridType("wilderness"), size: 100, distance: 1, units: "hex" }, drawings, walls, notes, flags: forgeFlag("wilderness", "wilderness", { seed, hexes }) };
  }

  static async createScene(preview, { publish = false, gmOnly = true } = {}) {
    const journal = await gmJournal(`${preview.name} — GM Prep`, [{ name: "Preparation", content: `<h1>${preview.name}</h1><p>Generated macro map. Resolve details through FORGE theatre of mind and distance bands.</p>` }]);
    const flags = foundry.utils.deepClone(preview.flags);
    flags.sceneMode = publish ? "published" : "draft";
    flags.gmSceneUuid = journal.uuid;
    const sceneData = {
      name: preview.name,
      width: preview.width,
      height: preview.height,
      padding: 0.1,
      grid: preview.grid,
      tokenVision: false,
      globalLight: true,
      ownership: { default: gmOnly ? CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE : CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER },
      flags: { forge: flags }
    };
    const scene = await Scene.create(sceneData);
    if (preview.drawings?.length) await scene.createEmbeddedDocuments("Drawing", preview.drawings);
    if (preview.walls?.length) await scene.createEmbeddedDocuments("Wall", preview.walls);
    const notes = preview.notes.map((note) => ({
      _id: note.id,
      entryId: journal.id,
      x: note.position.x,
      y: note.position.y,
      text: note.visibility === "gm" ? note.labelKey : "",
      icon: note.icon ?? "icons/svg/book.svg",
      flags: { forge: note }
    }));
    if (notes.length) await scene.createEmbeddedDocuments("Note", notes);
    return scene;
  }
}

export function registerForgeSceneGenerator() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.SceneGenerator = ForgeMacroSceneGenerator;
}
