/* FORGE Combat Tracker — ApplicationV2 presentation layer. */

import { ForgeCombatController } from "./forge-combat-controller.mjs";

const ApplicationV2 = foundry.applications.api.ApplicationV2;
const HandlebarsApplicationMixin = foundry.applications.api.HandlebarsApplicationMixin;

export class ForgeCombatTrackerApplication extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "forge-combat-tracker",
    classes: ["forge", "forge-combat-tracker"],
    tag: "section",
    position: { width: 380, height: 620 },
    window: { title: "FORGE Combat", resizable: true, icon: "fas fa-fire" },
    actions: {
      nextTurn: ForgeCombatTrackerApplication._onNextTurn,
      endCombat: ForgeCombatTrackerApplication._onEndCombat,
      resolveMorale: ForgeCombatTrackerApplication._onResolveMorale
    }
  };

  static PARTS = {
    body: { template: "systems/forge/templates/combat-tracker.hbs" }
  };

  async _prepareContext() {
    const combat = game.combat;
    if (!combat) return { hasCombat: false, title: game.i18n.localize("FORGE.Combat.noCombat") };
    const state = foundry.utils.deepClone(combat.getFlag("forge", "combatState") ?? {});
    const sides = Object.values(state.sides ?? {}).map((side) => ({
      ...side,
      combatants: combat.combatants.filter((combatant) => state.combatants?.[combatant.id]?.sideId === side.id).map((combatant) => ({
        id: combatant.id,
        name: combatant.name,
        img: combatant.token?.texture?.src ?? combatant.actor?.prototypeToken?.texture?.src ?? null,
        defeated: combatant.isDefeated,
        current: combat.current?.id === combatant.id,
        state: state.combatants?.[combatant.id] ?? {}
      }))
    }));
    return {
      hasCombat: true,
      title: combat.name,
      round: combat.round ?? 0,
      phase: state.phase ?? "setup",
      activeSide: state.activeSide ?? null,
      sideSequence: state.sideSequence ?? [],
      sides,
      automationMode: game.settings.get("forge", "automationMode"),
      userIsGM: game.user.isGM,
      distanceMode: state.distanceMode ?? "bands"
    };
  }

  static async _onNextTurn() {
    const combat = game.combat;
    if (!combat || !game.user.isGM) return;
    const current = combat.current?.id;
    if (current) await ForgeCombatController.useAction(combat, current, { kind: "endTurn", cost: "main", description: "Tracker end turn" });
    await combat.nextTurn();
  }

  static async _onEndCombat() {
    if (game.combat && game.user.isGM) await ForgeCombatController.endCombat(game.combat);
  }

  static async _onResolveMorale() {
    if (game.combat && game.user.isGM) await ForgeCombatController.moraleReview(game.combat);
  }
}

export function registerForgeCombatTracker() {
  CONFIG.FORGE = CONFIG.FORGE ?? {};
  CONFIG.FORGE.CombatTrackerApplication = ForgeCombatTrackerApplication;
  Hooks.on("renderCombatTracker", (app, html) => {
    html.dataset.forgePresentation = "available";
  });
}
